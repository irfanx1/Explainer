-- PostgreSQL initialization
-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";   -- fuzzy text search

-- Ensure the mangabot user has all privileges
GRANT ALL PRIVILEGES ON DATABASE mangabot TO mangabot;
