# 🎌 Manga → Animated Hindi Video Bot

A production-ready Telegram bot that converts manga (PDF/CBZ/ZIP) into animated Hindi explanation videos with AI narration, smart camera movement, and dynamic subtitles.

---

## 🏗 Architecture

```
Telegram Upload
      │
      ▼
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│  Bot Handler│────▶│  Celery Task │────▶│  Extractor  │ PDF/CBZ→PNG pages
└─────────────┘     └──────────────┘     └─────────────┘
                                                │
                                         ┌──────▼──────┐
                                         │  OCR Engine │ Tesseract/EasyOCR/Vision
                                         └──────┬──────┘
                                                │
                                         ┌──────▼──────┐
                                         │  GPT-4o AI  │ Story + Hindi narration
                                         └──────┬──────┘
                                                │
                                    ┌───────────▼────────────┐
                                    │  TTS  │  Animator      │ gTTS/ElevenLabs/Coqui
                                    │       │  OpenCV zoom   │ Ken Burns + mood filters
                                    └───────────┬────────────┘
                                                │
                                         ┌──────▼──────┐
                                         │   FFmpeg    │ Concat + subtitles + encode
                                         └──────┬──────┘
                                                │
                                         ┌──────▼──────┐
                                         │  Telegram   │ Send MP4 to user
                                         └─────────────┘
```

---

## 🚀 Quick Start (5 minutes)

### Prerequisites
- Docker + Docker Compose
- Telegram Bot Token → [@BotFather](https://t.me/BotFather)
- OpenAI API Key → [platform.openai.com](https://platform.openai.com)

### 1. Clone & configure

```bash
git clone https://github.com/youruser/manga-bot.git
cd manga-bot

cp .env.example .env
# Edit .env — fill in TELEGRAM_BOT_TOKEN and OPENAI_API_KEY at minimum
nano .env
```

### 2. Deploy

```bash
bash scripts/deploy.sh
```

That's it. The script builds images, migrates the DB, and starts all services.

### 3. Test the bot

Open Telegram → find your bot → `/start` → send a manga PDF.

---

## ⚙️ Configuration Reference (`.env`)

| Variable | Required | Default | Description |
|---|---|---|---|
| `TELEGRAM_BOT_TOKEN` | ✅ | — | From @BotFather |
| `OPENAI_API_KEY` | ✅ | — | GPT-4o for story analysis |
| `TELEGRAM_ADMIN_IDS` | ⬜ | — | Comma-separated Telegram user IDs |
| `DEFAULT_QUALITY` | ⬜ | `720p` | `480p` / `720p` / `1080p` |
| `OCR_ENGINE` | ⬜ | `tesseract` | `tesseract` / `easyocr` / `google_vision` |
| `TTS_ENGINE` | ⬜ | `gtts` | `gtts` / `elevenlabs` / `coqui` |
| `GPU_ENABLED` | ⬜ | `false` | `true` for NVIDIA GPU rendering |
| `STORAGE_BACKEND` | ⬜ | `local` | `local` / `s3` / `gcs` |
| `YOUTUBE_UPLOAD_ENABLED` | ⬜ | `false` | Enable /youtube command |
| `ELEVENLABS_API_KEY` | ⬜ | — | Premium TTS voices |

---

## 📁 Project Structure

```
manga_bot/
├── app/
│   ├── api/                    # FastAPI REST API
│   │   └── routes/             # health, jobs, admin, webhook
│   ├── bot/                    # Telegram bot
│   │   ├── handlers/           # convert, settings, status, history...
│   │   └── keyboards/          # InlineKeyboard builders
│   ├── core/                   # Config, DB, Redis, logging
│   ├── models/                 # SQLAlchemy ORM models
│   ├── services/
│   │   ├── ai/                 # extractor, OCR, story analyzer, TTS
│   │   ├── video/              # animator, subtitles, renderer
│   │   └── storage/            # local/S3/GCS + YouTube
│   ├── workers/                # Celery tasks + app factory
│   └── plugins/                # Plugin system + examples
├── alembic/                    # Database migrations
├── infrastructure/
│   ├── docker/
│   ├── nginx/
│   ├── postgres/
│   └── redis/
├── scripts/
│   ├── deploy.sh               # One-command deploy
│   └── manage.py               # CLI management
├── tests/
├── Dockerfile
├── Dockerfile.gpu              # NVIDIA CUDA variant
├── docker-compose.yml
├── docker-compose.gpu.yml      # GPU override
└── .env.example
```

---

## 🤖 Bot Commands

| Command | Description |
|---|---|
| `/start` | Welcome message |
| `/convert` | Prompt to upload manga file |
| `/settings` | Change quality, voice, TTS engine |
| `/status` | Live progress of active jobs |
| `/history` | Past 10 conversions |
| `/youtube` | Upload last video to YouTube |
| `/admin stats` | Admin: system statistics |
| `/admin users` | Admin: list users |
| `/admin ban <id>` | Admin: ban user |
| `/admin cancel <job_id>` | Admin: cancel running job |

---

## 🎬 Pipeline Details

### 1. Extraction
Supports PDF (PyMuPDF at 300 DPI), CBZ/ZIP, CBR/RAR, 7z. Pages are sorted naturally and normalized to consistent width.

### 2. OCR
- **Tesseract** (default, free): Japanese + English models
- **EasyOCR**: Better for stylized manga fonts, GPU accelerated
- **Google Vision**: Highest accuracy, requires API key

### 3. AI Story Analysis (GPT-4o)
Generates:
- Hindi narration per scene
- Character identification + relationship mapping
- Camera cue suggestions (zoom, pan, shake, flash)
- Mood tags → applied as colour filters
- Dialogue translation

### 4. TTS
- **gTTS**: Free, Indian Hindi accent
- **ElevenLabs**: Premium multilingual, natural voices
- **Coqui XTTS v2**: Local, GPU accelerated, no API cost

### 5. Animation
Ken Burns effect engine with:
- Zoom in/out with smooth easing
- Pan left/right/up/down
- Camera shake (action scenes)
- Flash effect (dramatic moments)
- Mood-based colour grading (tense=red tint, sad=desaturate, funny=saturated)

### 6. Subtitles
ASS format with:
- **dynamic** (default): fade-in with soft blur
- **cinema**: yellow, classic style
- **minimal**: clean white

### 7. Render
FFmpeg pipeline:
1. Scene clips concatenated
2. Audio merged per clip
3. Title card prepended
4. Subtitles burned in
5. Final H.264 MP4 output

---

## 🔌 Plugin System

```python
# Register a plugin
from app.plugins.manager import plugin_manager

await plugin_manager.register(
    name="my_effect",
    version="1.0.0",
    description="Custom video effect",
    module_path="app.plugins.my_effect",
    hook_type="video_effect",   # ocr | tts | video_effect | post_process
    config={"intensity": 0.5},
)
```

Plugin file template:
```python
# app/plugins/my_effect.py

async def hook(data, config=None, **kwargs):
    # data is frame (np.ndarray) for video_effect hook
    # Modify and return
    return data
```

---

## 🖥 GPU Setup

```bash
# Requires: NVIDIA driver + nvidia-container-toolkit
docker compose -f docker-compose.yml -f docker-compose.gpu.yml up -d
```

Set `GPU_ENABLED=true` in `.env`. Enables:
- EasyOCR GPU mode (3–5× faster)
- FFmpeg NVENC hardware encoding
- Coqui TTS GPU inference

---

## 📊 Monitoring

- **Flower** (Celery): http://localhost:5555 (admin/changeme)
- **API Docs**: http://localhost:8000/docs (dev mode only)
- **Admin API**: http://localhost:8000/api/v1/admin/stats (HTTP Basic Auth)

```bash
# Live logs
docker compose logs -f bot worker

# Worker status
docker compose exec worker celery -A app.workers.celery_app inspect active
```

---

## 🔄 Resume / Fault Tolerance

Jobs checkpoint each pipeline stage into the `artifacts` JSONB column. If a worker crashes mid-render, re-queuing the same `job_id` resumes from the last completed stage (no re-OCR, no re-TTS).

```bash
# Re-queue a failed job
docker compose exec api python -c "
from app.workers.tasks import process_manga
process_manga.apply_async(args=['YOUR-JOB-ID'], queue='pipeline')
"
```

---

## ☁️ Production Deployment (VPS)

```bash
# 1. SSH into your server
ssh user@your-server

# 2. Install Docker
curl -fsSL https://get.docker.com | sh

# 3. Clone repo and configure
git clone https://github.com/youruser/manga-bot && cd manga-bot
cp .env.example .env && nano .env

# 4. Deploy
bash scripts/deploy.sh

# 5. Optional: set up Telegram webhook instead of polling
curl "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
  -d "url=https://yourdomain.com/api/v1/webhook"
```

**Recommended VPS specs:**
- CPU mode: 4 vCPU, 8 GB RAM
- GPU mode: Any instance with NVIDIA T4/A10G

---

## 📜 License

MIT — free to use, modify, and deploy.
