"""Integration tests — FastAPI endpoints."""
import pytest
from httpx import AsyncClient, ASGITransport
from unittest.mock import AsyncMock, patch


@pytest.fixture
async def client():
    # Patch DB and Redis so tests run without infrastructure
    with patch("app.core.database.init_db", new_callable=AsyncMock), \
         patch("app.core.database.close_db", new_callable=AsyncMock), \
         patch("app.core.redis_client.close_redis", new_callable=AsyncMock), \
         patch("app.core.redis_client.get_redis", new_callable=AsyncMock) as mock_redis:

        mock_redis.return_value.ping = AsyncMock(return_value=True)

        from app.api.main import app
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
            yield ac


@pytest.mark.asyncio
async def test_health_endpoint(client):
    resp = await client.get("/api/v1/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"


@pytest.mark.asyncio
async def test_get_nonexistent_job(client):
    import uuid
    resp = await client.get(f"/api/v1/jobs/{uuid.uuid4()}")
    # Without DB it will error, but route should exist
    assert resp.status_code in (404, 500, 503)


@pytest.mark.asyncio
async def test_invalid_job_id(client):
    resp = await client.get("/api/v1/jobs/not-a-uuid")
    assert resp.status_code == 400
