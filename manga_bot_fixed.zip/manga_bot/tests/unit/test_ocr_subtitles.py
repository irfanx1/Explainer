"""Unit tests — OCR helpers and subtitle renderer."""
import pytest
from app.services.ai.ocr import OCRService, TextRegion
from app.services.video.subtitles import SubtitleRenderer, SubtitleEvent


class TestOCRMergeNearby:
    def test_merge_nearby_same_line(self):
        svc = OCRService()
        regions = [
            TextRegion("Hello", (0, 10, 50, 20), 0.9),
            TextRegion("World", (60, 10, 50, 20), 0.9),
        ]
        merged = svc._merge_nearby(regions, gap=15)
        assert len(merged) == 1
        assert "Hello" in merged[0].text
        assert "World" in merged[0].text

    def test_no_merge_different_lines(self):
        svc = OCRService()
        regions = [
            TextRegion("Line1", (0, 0, 50, 20), 0.9),
            TextRegion("Line2", (0, 50, 50, 20), 0.9),
        ]
        merged = svc._merge_nearby(regions, gap=15)
        assert len(merged) == 2

    def test_empty_input(self):
        svc = OCRService()
        assert svc._merge_nearby([]) == []


class TestSubtitleRenderer:
    def test_split_text_short(self):
        chunks = SubtitleRenderer._split_text("Hello", 40)
        assert chunks == ["Hello"]

    def test_split_text_long(self):
        text = "यह एक बहुत लंबा वाक्य है जो कि कई भागों में विभाजित होना चाहिए"
        chunks = SubtitleRenderer._split_text(text, 20)
        assert len(chunks) > 1
        for c in chunks:
            assert len(c) <= 25  # some slack for word boundaries

    def test_fmt_time(self):
        r = SubtitleRenderer()
        assert r._fmt_time(0) == "0:00:00.00"
        assert r._fmt_time(61.5) == "0:01:01.50"
        assert r._fmt_time(3661.0) == "1:01:01.00"

    def test_fmt_srt(self):
        r = SubtitleRenderer()
        assert r._fmt_srt(0) == "00:00:00,000"
        assert r._fmt_srt(61.5) == "00:01:01,500"

    def test_events_to_ass(self, tmp_path):
        r = SubtitleRenderer()
        events = [
            SubtitleEvent(0.0, 3.0, "नमस्ते दुनिया"),
            SubtitleEvent(3.0, 6.0, "यह एक परीक्षण है"),
        ]
        out = str(tmp_path / "test.ass")
        r.events_to_ass(events, out)
        content = open(out, encoding="utf-8").read()
        assert "[Script Info]" in content
        assert "नमस्ते दुनिया" in content
        assert "Dialogue:" in content

    def test_build_events_from_analysis(self):
        narrations = [
            {"text": "यह मंगा बहुत अच्छी है", "start_sec": 0.0, "end_sec": 4.0},
        ]
        events = SubtitleRenderer.build_events_from_analysis(narrations)
        assert len(events) >= 1
        assert events[0].start_sec == 0.0
        assert events[-1].end_sec == pytest.approx(4.0, abs=0.1)
