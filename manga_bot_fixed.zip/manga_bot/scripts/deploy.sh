#!/bin/bash
# ============================================================
#  MangaBot Deploy Script
# ============================================================
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}🎌 MangaBot Deploy Script${NC}"
echo "================================="

# Check .env exists
if [ ! -f ".env" ]; then
    echo -e "${YELLOW}⚠️  .env not found. Copying from .env.example...${NC}"
    cp .env.example .env
    echo -e "${RED}❗ Please edit .env and set your TELEGRAM_BOT_TOKEN and OPENAI_API_KEY before continuing!${NC}"
    exit 1
fi

# Check required env vars
source .env
if [ -z "$TELEGRAM_BOT_TOKEN" ] || [ "$TELEGRAM_BOT_TOKEN" = "your_bot_token_here" ]; then
    echo -e "${RED}❌ TELEGRAM_BOT_TOKEN is not set in .env!${NC}"
    exit 1
fi

echo -e "${GREEN}✅ .env looks good${NC}"

# Build images
echo -e "${YELLOW}🔨 Building Docker images...${NC}"
docker compose build

# Start infrastructure first
echo -e "${YELLOW}🚀 Starting infrastructure (postgres, redis)...${NC}"
docker compose up -d postgres redis

# Wait for healthy
echo -e "${YELLOW}⏳ Waiting for postgres and redis to be ready...${NC}"
sleep 5
docker compose up migrate

# Start all services
echo -e "${YELLOW}🚀 Starting all services...${NC}"
docker compose up -d api bot worker worker_upload flower nginx

echo ""
echo -e "${GREEN}✅ MangaBot is running!${NC}"
echo "================================="
echo "📊 API:    http://localhost:8000/docs"
echo "🌸 Flower: http://localhost:5555"
echo "🌐 Nginx:  http://localhost:80"
echo ""
echo "View logs: docker compose logs -f bot"
echo "Stop all:  docker compose down"
