#!/usr/bin/env python3
"""
Management CLI — shortcuts for common operations.
Usage:
  python scripts/manage.py db-upgrade
  python scripts/manage.py create-admin --id 123456
  python scripts/manage.py worker
  python scripts/manage.py bot
  python scripts/manage.py api
"""
import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


def cmd_db_upgrade():
    """Run Alembic migrations."""
    os.system("alembic upgrade head")


def cmd_db_downgrade():
    os.system("alembic downgrade -1")


def cmd_db_init():
    """Create tables directly (dev only)."""
    async def _run():
        from app.core.database import init_db
        await init_db()
        print("✅ Tables created.")
    asyncio.run(_run())


def cmd_create_admin(telegram_id: int):
    async def _run():
        from app.core.database import AsyncSessionLocal
        from app.models.user import User
        from sqlalchemy import select
        async with AsyncSessionLocal() as db:
            result = await db.execute(select(User).where(User.telegram_id == telegram_id))
            user = result.scalar_one_or_none()
            if not user:
                user = User(telegram_id=telegram_id, username="admin", is_admin=True)
                db.add(user)
            else:
                user.is_admin = True
            await db.commit()
        print(f"✅ Admin privileges granted to {telegram_id}")
    asyncio.run(_run())


def cmd_worker():
    os.execvp("celery", [
        "celery", "-A", "app.workers.celery_app", "worker",
        "--loglevel=info", "--queues=pipeline,upload", "--concurrency=2",
    ])


def cmd_bot():
    from app.bot.main import main
    main()


def cmd_api():
    os.execvp("uvicorn", [
        "uvicorn", "app.api.main:app",
        "--host", "0.0.0.0", "--port", "8000", "--reload",
    ])


def cmd_flower():
    os.execvp("celery", [
        "celery", "-A", "app.workers.celery_app", "flower", "--port=5555",
    ])


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="MangaBot management CLI")
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("db-upgrade")
    subparsers.add_parser("db-downgrade")
    subparsers.add_parser("db-init")
    subparsers.add_parser("worker")
    subparsers.add_parser("bot")
    subparsers.add_parser("api")
    subparsers.add_parser("flower")

    p_admin = subparsers.add_parser("create-admin")
    p_admin.add_argument("--id", type=int, required=True, dest="telegram_id")

    args = parser.parse_args()

    match args.command:
        case "db-upgrade":   cmd_db_upgrade()
        case "db-downgrade": cmd_db_downgrade()
        case "db-init":      cmd_db_init()
        case "worker":       cmd_worker()
        case "bot":          cmd_bot()
        case "api":          cmd_api()
        case "flower":       cmd_flower()
        case "create-admin": cmd_create_admin(args.telegram_id)
        case _:              parser.print_help()
