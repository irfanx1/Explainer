from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, DateTime, Enum, Float, ForeignKey, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class JobStatus(str, enum.Enum):
    PENDING    = "pending"
    EXTRACTING = "extracting"
    OCR        = "ocr"
    AI_ANALYZE = "ai_analyze"
    TTS        = "tts"
    RENDERING  = "rendering"
    UPLOADING  = "uploading"
    DONE       = "done"
    FAILED     = "failed"
    CANCELLED  = "cancelled"
    PAUSED     = "paused"


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    user_telegram_id: Mapped[int] = mapped_column(BigInteger, index=True)
    celery_task_id: Mapped[Optional[str]] = mapped_column(String(128))

    # Input
    original_filename: Mapped[Optional[str]] = mapped_column(String(256))
    file_path: Mapped[Optional[str]] = mapped_column(Text)
    file_size_bytes: Mapped[Optional[int]] = mapped_column(Integer)
    total_pages: Mapped[Optional[int]] = mapped_column(Integer)

    # Settings snapshot at submission
    quality: Mapped[str] = mapped_column(String(16), default="720p")
    voice_mode: Mapped[str] = mapped_column(String(32), default="female")
    tts_engine: Mapped[str] = mapped_column(String(32), default="gtts")
    language: Mapped[str] = mapped_column(String(8), default="hi")

    # Status
    status: Mapped[JobStatus] = mapped_column(
        Enum(JobStatus), default=JobStatus.PENDING, index=True
    )
    progress_pct: Mapped[float] = mapped_column(Float, default=0.0)
    current_step: Mapped[Optional[str]] = mapped_column(String(128))
    error_message: Mapped[Optional[str]] = mapped_column(Text)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)

    # Output
    output_path: Mapped[Optional[str]] = mapped_column(Text)
    output_url: Mapped[Optional[str]] = mapped_column(Text)
    video_duration_seconds: Mapped[Optional[float]] = mapped_column(Float)
    youtube_url: Mapped[Optional[str]] = mapped_column(Text)

    # Pipeline intermediate artifacts (for resume)
    artifacts: Mapped[dict] = mapped_column(JSONB, default=dict)
    ai_analysis: Mapped[dict] = mapped_column(JSONB, default=dict)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
