from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Character(Base):
    """Persisted character memory across jobs for a user."""
    __tablename__ = "characters"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_telegram_id: Mapped[int] = mapped_column(BigInteger, index=True)
    series_name: Mapped[str] = mapped_column(String(256), index=True)
    character_name: Mapped[str] = mapped_column(String(128))
    aliases: Mapped[list] = mapped_column(JSONB, default=list)
    description: Mapped[str] = mapped_column(Text, default="")
    personality_traits: Mapped[list] = mapped_column(JSONB, default=list)
    appearance: Mapped[dict] = mapped_column(JSONB, default=dict)
    relationships: Mapped[dict] = mapped_column(JSONB, default=dict)  # {char_name: relationship}
    first_seen_page: Mapped[int] = mapped_column(default=0)
    embedding: Mapped[list] = mapped_column(JSONB, default=list)  # vector for similarity
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())
