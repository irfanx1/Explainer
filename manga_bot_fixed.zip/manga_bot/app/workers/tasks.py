"""
Core Celery tasks — full manga→video pipeline.
Supports: progress reporting, resume from checkpoint, retry on failure.
"""
from __future__ import annotations

import asyncio
import os
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from celery import Task
from sqlalchemy import select

from app.core.config import settings
from app.core.database import AsyncSessionLocal
from app.core.logging import get_logger, setup_logging
from app.core.redis_client import publish, set_job_progress
from app.models.job import Job, JobStatus
from app.services.ai.character_memory import CharacterMemoryService
from app.services.ai.extractor import MangaExtractor
from app.services.ai.ocr import OCRService
from app.services.ai.story_analyzer import StoryAnalyzer
from app.services.ai.tts import TTSService
from app.services.storage.storage import StorageService
from app.services.video.renderer import VideoRenderer
from app.workers.celery_app import celery_app

setup_logging()
log = get_logger(__name__)

MAX_RETRIES = 3


def run_async(coro):
    """Run async coroutine from sync Celery task."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


async def _update_job(job_id: str, **kwargs) -> None:
    import uuid as _uuid
    async with AsyncSessionLocal() as db:
        stmt = select(Job).where(Job.id == _uuid.UUID(job_id) if isinstance(job_id, str) else job_id)
        result = await db.execute(stmt)
        job = result.scalar_one_or_none()
        if job:
            for k, v in kwargs.items():
                setattr(job, k, v)
            await db.commit()


async def _get_job(job_id: str) -> Optional[Job]:
    import uuid as _uuid
    async with AsyncSessionLocal() as db:
        stmt = select(Job).where(Job.id == _uuid.UUID(job_id) if isinstance(job_id, str) else job_id)
        result = await db.execute(stmt)
        return result.scalar_one_or_none()


@celery_app.task(
    bind=True,
    name="app.workers.tasks.process_manga",
    max_retries=MAX_RETRIES,
    default_retry_delay=30,
    acks_late=True,
)
def process_manga(self: Task, job_id: str) -> dict:
    """
    Master pipeline task.
    Steps:
      1. Extract pages
      2. OCR
      3. AI story analysis
      4. Video render (TTS + animation + subtitles)
      5. Upload output
      6. Notify via Redis pub/sub
    """
    log.info("task.start", job_id=job_id, celery_id=self.request.id)

    def progress(pct: float, step: str):
        run_async(_update_job(job_id, progress_pct=pct, current_step=step))
        run_async(set_job_progress(job_id, {"pct": pct, "step": step}))
        run_async(publish("job_progress", {"job_id": job_id, "pct": pct, "step": step}))

    try:
        job = run_async(_get_job(job_id))
        if not job:
            raise ValueError(f"Job {job_id} not found")

        work_dir = str(Path(settings.temp_dir) / job_id)
        os.makedirs(work_dir, exist_ok=True)

        # Resume from artifacts
        artifacts = job.artifacts or {}

        # ── 1. Extract ──────────────────────────────────────────────────
        run_async(_update_job(job_id, status=JobStatus.EXTRACTING, started_at=datetime.now(timezone.utc)))
        progress(5, "Extracting manga pages…")

        extractor = MangaExtractor(work_dir=settings.temp_dir)
        if "page_images" in artifacts:
            page_images = artifacts["page_images"]
            log.info("task.resume", step="extract", pages=len(page_images))
        else:
            page_images = extractor.extract(job.file_path, job_id)
            # Normalize all pages
            for p in page_images:
                extractor.normalize_page(p)
            artifacts["page_images"] = page_images
            run_async(_update_job(
                job_id,
                total_pages=len(page_images),
                artifacts=artifacts,
            ))

        progress(15, f"Extracted {len(page_images)} pages")

        # ── 2. OCR ──────────────────────────────────────────────────────
        run_async(_update_job(job_id, status=JobStatus.OCR))
        progress(20, "Running OCR…")

        if "ocr_results" in artifacts:
            ocr_data = artifacts["ocr_results"]
            log.info("task.resume", step="ocr")
        else:
            ocr_svc = OCRService()
            ocr_results = ocr_svc.process_pages(page_images)
            ocr_data = [
                {"page_index": r.page_index, "full_text": r.full_text}
                for r in ocr_results
            ]
            artifacts["ocr_results"] = ocr_data
            run_async(_update_job(job_id, artifacts=artifacts))

        progress(35, f"OCR complete — {sum(len(r['full_text']) for r in ocr_data)} chars")

        # ── 3. AI Analysis ──────────────────────────────────────────────
        run_async(_update_job(job_id, status=JobStatus.AI_ANALYZE))
        progress(40, "AI story analysis…")

        if "analysis" in artifacts:
            analysis_dict = artifacts["analysis"]
        else:
            # Load character memory
            mem_svc = CharacterMemoryService()
            known_chars = run_async(
                mem_svc.get_known_characters(job.user_telegram_id, "unknown")
            )

            # Reconstruct OCR result objects
            from app.services.ai.ocr import PageOCRResult
            ocr_obj = [
                PageOCRResult(page_index=r["page_index"], image_path="", full_text=r["full_text"])
                for r in ocr_data
            ]

            analyzer = StoryAnalyzer()
            analysis = run_async(analyzer.analyze(ocr_obj, known_chars))

            # Save character memory
            run_async(mem_svc.update_from_analysis(
                job.user_telegram_id, analysis.series_title, analysis
            ))

            # Serialise analysis to dict for storage
            import dataclasses, json
            analysis_dict = dataclasses.asdict(analysis)
            artifacts["analysis"] = analysis_dict
            run_async(_update_job(job_id, artifacts=artifacts, ai_analysis=analysis_dict))

        progress(55, "Story analyzed!")

        # ── 4. Render ───────────────────────────────────────────────────
        run_async(_update_job(job_id, status=JobStatus.RENDERING))
        progress(60, "Rendering video…")

        output_mp4 = os.path.join(work_dir, "final.mp4")

        renderer = VideoRenderer(
            quality=job.quality,
            voice_mode=job.voice_mode,
            tts_engine=job.tts_engine,
            subtitle_style="dynamic",
        )

        # Rebuild analysis from dict
        from app.services.ai.story_analyzer import StoryAnalysis, SceneInfo, CharacterInfo
        def _rebuild_analysis(d: dict) -> StoryAnalysis:
            chars = [CharacterInfo(**c) for c in d.get("characters", [])]
            scenes = [SceneInfo(**s) for s in d.get("scenes", [])]
            return StoryAnalysis(
                series_title=d["series_title"],
                chapter_hint=d.get("chapter_hint", ""),
                genre=d.get("genre", []),
                overall_summary_hindi=d.get("overall_summary_hindi", ""),
                overall_summary_english=d.get("overall_summary_english", ""),
                characters=chars,
                scenes=scenes,
                reading_time_estimate=d.get("reading_time_estimate", 120),
                pacing=d.get("pacing", "medium"),
            )

        analysis_obj = _rebuild_analysis(analysis_dict)
        merged_artifacts = artifacts.get("render_artifacts", {})

        run_async(renderer.render(
            analysis=analysis_obj,
            page_images=page_images,
            work_dir=work_dir,
            output_path=output_mp4,
            progress_cb=lambda p, s: progress(60 + p * 0.3, s),
            resume_artifacts=merged_artifacts,
        ))

        # ── 5. Upload ───────────────────────────────────────────────────
        run_async(_update_job(job_id, status=JobStatus.UPLOADING))
        progress(92, "Uploading video…")

        storage = StorageService()
        key = f"videos/{job.user_telegram_id}/{job_id}/final.mp4"
        output_url = run_async(storage.upload(output_mp4, key))

        # Get duration
        from app.services.ai.tts import TTSService as _TTS
        try:
            from pydub import AudioSegment
            # Use ffprobe for video duration
            import subprocess, json as _json
            probe = subprocess.run(
                ["ffprobe", "-v", "quiet", "-print_format", "json",
                 "-show_format", output_mp4],
                capture_output=True, text=True,
            )
            dur = float(_json.loads(probe.stdout).get("format", {}).get("duration", 0))
        except Exception:
            dur = 0.0

        run_async(_update_job(
            job_id,
            status=JobStatus.DONE,
            output_path=output_mp4,
            output_url=output_url,
            video_duration_seconds=dur,
            progress_pct=100.0,
            finished_at=datetime.now(timezone.utc),
        ))

        # Notify Telegram bot via Redis
        run_async(publish("job_done", {
            "job_id": job_id,
            "user_telegram_id": job.user_telegram_id,
            "output_path": output_mp4,
            "output_url": output_url,
            "duration": dur,
            "series_title": analysis_dict.get("series_title", ""),
        }))

        log.info("task.done", job_id=job_id)
        return {"status": "done", "output_url": output_url}

    except Exception as exc:
        log.error("task.failed", job_id=job_id, error=str(exc))
        run_async(_update_job(
            job_id,
            status=JobStatus.FAILED,
            error_message=str(exc),
            finished_at=datetime.now(timezone.utc),
        ))
        _failed_job = run_async(_get_job(job_id))
        run_async(publish("job_failed", {
            "job_id": job_id,
            "user_telegram_id": _failed_job.user_telegram_id if _failed_job else 0,
            "error": str(exc),
        }))
        raise self.retry(exc=exc, countdown=60 * (self.request.retries + 1))


@celery_app.task(name="app.workers.tasks.upload_youtube")
def upload_youtube(job_id: str) -> dict:
    """Optional: upload finished video to YouTube."""
    job = run_async(_get_job(job_id))
    if not job or not job.output_path:
        raise ValueError("Job not found or no output")
    from app.services.storage.youtube import YouTubeUploader
    yt = YouTubeUploader()
    title = f"Manga Explained in Hindi | {job.ai_analysis.get('series_title', 'Manga')}"
    description = job.ai_analysis.get("overall_summary_hindi", "")
    url = yt.upload(job.output_path, title, description)
    run_async(_update_job(job_id, youtube_url=url))
    run_async(publish("youtube_done", {"job_id": job_id, "url": url,
                                        "user_telegram_id": job.user_telegram_id}))
    return {"url": url}
