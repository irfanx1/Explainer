"""Celery application factory."""
from celery import Celery
from app.core.config import settings

celery_app = Celery(
    "mangabot",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=["app.workers.tasks"],
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="Asia/Kolkata",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_routes={
        "app.workers.tasks.process_manga": {"queue": "pipeline"},
        "app.workers.tasks.upload_youtube": {"queue": "upload"},
    },
    beat_schedule={},
)
