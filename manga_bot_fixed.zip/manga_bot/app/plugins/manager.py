"""
Plugin Manager — dynamic loading of processing plugins.
Hook types: ocr | tts | video_effect | post_process
"""
from __future__ import annotations

import importlib
from typing import Any, Callable, Dict, List, Optional

from app.core.database import AsyncSessionLocal
from app.core.logging import get_logger
from app.models.plugin import Plugin
from sqlalchemy import select

log = get_logger(__name__)

# Registry: hook_type → list of callables
_registry: Dict[str, List[Callable]] = {}


class PluginManager:
    """Load and invoke plugins registered in the database."""

    async def load_all(self) -> None:
        async with AsyncSessionLocal() as db:
            result = await db.execute(select(Plugin).where(Plugin.is_enabled == True))
            plugins = result.scalars().all()

        for plugin in plugins:
            self._load(plugin)

        log.info("plugins.loaded", count=len(plugins))

    def _load(self, plugin: Plugin) -> None:
        try:
            module = importlib.import_module(plugin.module_path)
            hook_fn = getattr(module, "hook", None)
            if hook_fn is None:
                log.warning("plugin.no_hook", name=plugin.name)
                return
            hook_type = plugin.hook_type
            if hook_type not in _registry:
                _registry[hook_type] = []
            _registry[hook_type].append(hook_fn)
            log.info("plugin.registered", name=plugin.name, hook=hook_type)
        except Exception as e:
            log.error("plugin.load_failed", name=plugin.name, error=str(e))

    def get_hooks(self, hook_type: str) -> List[Callable]:
        return _registry.get(hook_type, [])

    async def run_hooks(self, hook_type: str, data: Any, **kwargs) -> Any:
        """Run all plugins of a given hook type sequentially, passing data through."""
        for fn in self.get_hooks(hook_type):
            try:
                import asyncio
                if asyncio.iscoroutinefunction(fn):
                    data = await fn(data, **kwargs)
                else:
                    data = fn(data, **kwargs)
            except Exception as e:
                log.error("plugin.hook_failed", hook=hook_type, error=str(e))
        return data

    async def register(
        self,
        name: str,
        version: str,
        description: str,
        module_path: str,
        hook_type: str,
        config: Optional[dict] = None,
    ) -> Plugin:
        async with AsyncSessionLocal() as db:
            plugin = Plugin(
                name=name,
                version=version,
                description=description,
                module_path=module_path,
                hook_type=hook_type,
                config=config or {},
            )
            db.add(plugin)
            await db.commit()
            await db.refresh(plugin)
        self._load(plugin)
        return plugin

    async def disable(self, name: str) -> None:
        async with AsyncSessionLocal() as db:
            result = await db.execute(select(Plugin).where(Plugin.name == name))
            plugin = result.scalar_one_or_none()
            if plugin:
                plugin.is_enabled = False
                await db.commit()


# Singleton
plugin_manager = PluginManager()


# ── Example plugin interface (drop into app/plugins/) ─────────────────────────
EXAMPLE_PLUGIN_TEMPLATE = '''
"""
Example post-process plugin.
Place this file at app/plugins/my_plugin.py and register via API.
"""

async def hook(data, **kwargs):
    """
    data: depends on hook_type
      - ocr: List[PageOCRResult]
      - tts: str (audio path)
      - video_effect: np.ndarray (frame)
      - post_process: str (final video path)
    """
    # Your processing logic here
    return data
'''
