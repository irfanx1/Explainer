"""
Watermark Plugin — adds a text watermark to every video frame.
Hook type: video_effect
Register with: plugin_manager.register(
    name="watermark",
    version="1.0.0",
    description="Adds text watermark to frames",
    module_path="app.plugins.watermark",
    hook_type="video_effect",
    config={"text": "@YourChannel", "opacity": 0.4},
)
"""
from __future__ import annotations

import cv2
import numpy as np


def hook(frame: np.ndarray, config: dict = None, **kwargs) -> np.ndarray:
    config = config or {}
    text = config.get("text", "@MangaBot")
    opacity = float(config.get("opacity", 0.3))

    overlay = frame.copy()
    h, w = frame.shape[:2]
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = w / 1280 * 0.8
    thickness = max(1, int(font_scale * 2))
    color = (255, 255, 255)

    (tw, th), _ = cv2.getTextSize(text, font, font_scale, thickness)
    x = w - tw - 20
    y = h - 20

    cv2.putText(overlay, text, (x, y), font, font_scale, color, thickness, cv2.LINE_AA)
    return cv2.addWeighted(overlay, opacity, frame, 1 - opacity, 0)
