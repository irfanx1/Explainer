"""
Storage Service — unified interface for local / S3 / GCS backends.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Optional

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


class StorageService:
    def __init__(self):
        self.backend = settings.storage_backend
        self.base_dir = Path(settings.temp_dir) / "outputs"
        self.base_dir.mkdir(parents=True, exist_ok=True)

    async def upload(self, local_path: str, key: str) -> str:
        """Upload file and return public URL or local path."""
        if self.backend == "local":
            return self._local_store(local_path, key)
        elif self.backend == "s3":
            return await self._s3_upload(local_path, key)
        elif self.backend == "gcs":
            return await self._gcs_upload(local_path, key)
        raise ValueError(f"Unknown storage backend: {self.backend}")

    async def download(self, key: str, local_path: str) -> str:
        if self.backend == "local":
            src = self.base_dir / key
            shutil.copy2(str(src), local_path)
            return local_path
        raise NotImplementedError

    async def delete(self, key: str) -> None:
        if self.backend == "local":
            p = self.base_dir / key
            if p.exists():
                p.unlink()
        elif self.backend == "s3":
            await self._s3_delete(key)

    # ─────────────────────────────────────────────────────────────────────────

    def _local_store(self, local_path: str, key: str) -> str:
        dest = self.base_dir / key
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(local_path, str(dest))
        return str(dest)

    async def _s3_upload(self, local_path: str, key: str) -> str:
        import boto3
        s3 = boto3.client(
            "s3",
            region_name=settings.s3_region,
            aws_access_key_id=settings.aws_access_key_id,
            aws_secret_access_key=settings.aws_secret_access_key,
        )
        s3.upload_file(local_path, settings.s3_bucket, key)
        url = f"https://{settings.s3_bucket}.s3.{settings.s3_region}.amazonaws.com/{key}"
        log.info("storage.s3_uploaded", key=key, url=url)
        return url

    async def _s3_delete(self, key: str) -> None:
        import boto3
        s3 = boto3.client("s3",
            aws_access_key_id=settings.aws_access_key_id,
            aws_secret_access_key=settings.aws_secret_access_key,
        )
        s3.delete_object(Bucket=settings.s3_bucket, Key=key)

    async def _gcs_upload(self, local_path: str, key: str) -> str:
        from google.cloud import storage as gcs_lib
        client = gcs_lib.Client.from_service_account_json(settings.gcs_credentials_json)
        bucket = client.bucket(settings.gcs_bucket)
        blob = bucket.blob(key)
        blob.upload_from_filename(local_path)
        blob.make_public()
        url = blob.public_url
        log.info("storage.gcs_uploaded", key=key, url=url)
        return url
