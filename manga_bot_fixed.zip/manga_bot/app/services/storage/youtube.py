"""YouTube upload service using Google API."""
from __future__ import annotations

import os
from typing import Optional

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


class YouTubeUploader:
    def __init__(self):
        if not settings.youtube_upload_enabled:
            raise RuntimeError("YouTube upload is disabled. Set YOUTUBE_UPLOAD_ENABLED=true")
        self.secrets_json = settings.youtube_client_secrets_json

    def upload(
        self,
        video_path: str,
        title: str,
        description: str,
        tags: Optional[list] = None,
        privacy: str = "unlisted",
    ) -> str:
        """Upload video and return YouTube URL."""
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload
        from google_auth_oauthlib.flow import InstalledAppFlow

        SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
        flow = InstalledAppFlow.from_client_secrets_file(self.secrets_json, SCOPES)
        credentials = flow.run_local_server(port=0)
        youtube = build("youtube", "v3", credentials=credentials)

        body = {
            "snippet": {
                "title": title[:100],
                "description": description[:5000],
                "tags": tags or ["manga", "hindi", "anime"],
                "categoryId": "24",
            },
            "status": {"privacyStatus": privacy},
        }

        media = MediaFileUpload(video_path, chunksize=-1, resumable=True, mimetype="video/mp4")
        request = youtube.videos().insert(part=",".join(body.keys()), body=body, media_body=media)

        response = None
        while response is None:
            status, response = request.next_chunk()
            if status:
                log.info("youtube.upload_progress", pct=int(status.progress() * 100))

        video_id = response["id"]
        url = f"https://youtu.be/{video_id}"
        log.info("youtube.uploaded", url=url)
        return url
