"""
Character Memory Service — persists and retrieves character knowledge
across multiple manga uploads for each user/series.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from sqlalchemy import select

from app.core.database import AsyncSessionLocal
from app.core.logging import get_logger
from app.models.character import Character
from app.services.ai.story_analyzer import CharacterInfo, StoryAnalysis

log = get_logger(__name__)


class CharacterMemoryService:

    async def get_known_characters(
        self, user_telegram_id: int, series_name: str
    ) -> List[Dict]:
        async with AsyncSessionLocal() as db:
            stmt = select(Character).where(
                Character.user_telegram_id == user_telegram_id,
                Character.series_name == series_name,
            )
            result = await db.execute(stmt)
            chars = result.scalars().all()
            return [self._to_dict(c) for c in chars]

    async def update_from_analysis(
        self,
        user_telegram_id: int,
        series_name: str,
        analysis: StoryAnalysis,
    ) -> None:
        async with AsyncSessionLocal() as db:
            for char_info in analysis.characters:
                # Look for existing
                stmt = select(Character).where(
                    Character.user_telegram_id == user_telegram_id,
                    Character.series_name == series_name,
                    Character.character_name == char_info.name,
                )
                result = await db.execute(stmt)
                existing = result.scalar_one_or_none()

                if existing:
                    # Merge new knowledge
                    existing.description = char_info.description or existing.description
                    existing.personality_traits = list(
                        set(existing.personality_traits + char_info.personality)
                    )
                    existing.relationships.update(char_info.relationships)
                    if char_info.aliases:
                        existing.aliases = list(set(existing.aliases + char_info.aliases))
                else:
                    char = Character(
                        user_telegram_id=user_telegram_id,
                        series_name=series_name,
                        character_name=char_info.name,
                        aliases=char_info.aliases,
                        description=char_info.description,
                        personality_traits=char_info.personality,
                        relationships=char_info.relationships,
                    )
                    db.add(char)
            await db.commit()
        log.info("character_memory.updated", series=series_name, chars=len(analysis.characters))

    async def clear_series(
        self, user_telegram_id: int, series_name: str
    ) -> int:
        from sqlalchemy import delete
        async with AsyncSessionLocal() as db:
            stmt = delete(Character).where(
                Character.user_telegram_id == user_telegram_id,
                Character.series_name == series_name,
            )
            result = await db.execute(stmt)
            await db.commit()
            return result.rowcount

    def _to_dict(self, c: Character) -> Dict:
        return {
            "name": c.character_name,
            "aliases": c.aliases,
            "description": c.description,
            "personality": c.personality_traits,
            "relationships": c.relationships,
        }
