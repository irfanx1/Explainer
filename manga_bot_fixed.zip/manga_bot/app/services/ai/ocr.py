"""
OCR Service — extracts text from manga panels.
Engines: Tesseract (default) | EasyOCR | Google Vision.
Also detects speech bubbles and assigns text to panels.
"""
from __future__ import annotations

import base64
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
from PIL import Image

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


@dataclass
class TextRegion:
    text: str
    bbox: Tuple[int, int, int, int]   # x, y, w, h
    confidence: float = 0.0
    is_speech_bubble: bool = False
    speaker_hint: Optional[str] = None


@dataclass
class PageOCRResult:
    page_index: int
    image_path: str
    regions: List[TextRegion] = field(default_factory=list)
    full_text: str = ""
    language_detected: str = "unknown"


class OCRService:
    def __init__(self):
        self.engine = settings.ocr_engine
        self._easyocr_reader = None   # lazy init (heavy)

    # ─────────────────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────────────────

    def process_page(self, image_path: str, page_index: int) -> PageOCRResult:
        log.debug("ocr.page", index=page_index, engine=self.engine)
        result = PageOCRResult(page_index=page_index, image_path=image_path)

        if self.engine == "tesseract":
            result.regions = self._tesseract(image_path)
        elif self.engine == "easyocr":
            result.regions = self._easyocr(image_path)
        elif self.engine == "google_vision":
            result.regions = self._google_vision(image_path)

        result.full_text = " ".join(r.text for r in result.regions if r.text.strip())
        return result

    def process_pages(self, image_paths: List[str]) -> List[PageOCRResult]:
        return [self.process_page(p, i) for i, p in enumerate(image_paths)]

    # ─────────────────────────────────────────────────────────────────────────
    # Engines
    # ─────────────────────────────────────────────────────────────────────────

    def _tesseract(self, image_path: str) -> List[TextRegion]:
        try:
            import pytesseract
            img = Image.open(image_path)
            data = pytesseract.image_to_data(
                img,
                lang="jpn+eng",
                output_type=pytesseract.Output.DICT,
            )
            regions = []
            for i, text in enumerate(data["text"]):
                text = text.strip()
                if not text:
                    continue
                conf = float(data["conf"][i])
                if conf < 30:
                    continue
                regions.append(TextRegion(
                    text=text,
                    bbox=(data["left"][i], data["top"][i], data["width"][i], data["height"][i]),
                    confidence=conf / 100,
                ))
            return self._merge_nearby(regions)
        except Exception as e:
            log.warning("ocr.tesseract_failed", error=str(e))
            return []

    def _easyocr(self, image_path: str) -> List[TextRegion]:
        try:
            import easyocr
            if self._easyocr_reader is None:
                self._easyocr_reader = easyocr.Reader(
                    ["ja", "en"], gpu=settings.gpu_enabled
                )
            results = self._easyocr_reader.readtext(image_path)
            regions = []
            for bbox_pts, text, conf in results:
                pts = np.array(bbox_pts, dtype=int)
                x, y = int(pts[:, 0].min()), int(pts[:, 1].min())
                w = int(pts[:, 0].max()) - x
                h = int(pts[:, 1].max()) - y
                regions.append(TextRegion(
                    text=text.strip(),
                    bbox=(x, y, w, h),
                    confidence=float(conf),
                    is_speech_bubble=self._is_bubble_region(image_path, x, y, w, h),
                ))
            return regions
        except Exception as e:
            log.warning("ocr.easyocr_failed", error=str(e))
            return []

    def _google_vision(self, image_path: str) -> List[TextRegion]:
        try:
            from google.cloud import vision
            client = vision.ImageAnnotatorClient()
            with open(image_path, "rb") as f:
                content = f.read()
            image = vision.Image(content=content)
            response = client.document_text_detection(image=image)
            regions = []
            for page in response.full_text_annotation.pages:
                for block in page.blocks:
                    text_parts = []
                    for para in block.paragraphs:
                        for word in para.words:
                            text_parts.append("".join(s.text for s in word.symbols))
                    text = " ".join(text_parts).strip()
                    if not text:
                        continue
                    verts = block.bounding_box.vertices
                    x = min(v.x for v in verts)
                    y = min(v.y for v in verts)
                    w = max(v.x for v in verts) - x
                    h = max(v.y for v in verts) - y
                    regions.append(TextRegion(
                        text=text,
                        bbox=(x, y, w, h),
                        confidence=float(block.confidence),
                    ))
            return regions
        except Exception as e:
            log.warning("ocr.vision_failed", error=str(e))
            return []

    # ─────────────────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _is_bubble_region(self, image_path: str, x: int, y: int, w: int, h: int) -> bool:
        """Heuristic: check if region background is white (speech bubble)."""
        try:
            img = cv2.imread(image_path)
            roi = img[y:y+h, x:x+w]
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            _, thresh = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
            white_ratio = thresh.sum() / (thresh.size * 255)
            return white_ratio > 0.5
        except Exception:
            return False

    def _merge_nearby(self, regions: List[TextRegion], gap: int = 15) -> List[TextRegion]:
        """Merge Tesseract word-level results into line-level."""
        if not regions:
            return []
        merged = []
        current = regions[0]
        for r in regions[1:]:
            cx, cy, cw, ch = current.bbox
            rx, ry, rw, rh = r.bbox
            same_line = abs(cy - ry) < gap
            close_x = abs((cx + cw) - rx) < gap * 3
            if same_line and close_x:
                new_x = min(cx, rx)
                new_y = min(cy, ry)
                new_w = max(cx + cw, rx + rw) - new_x
                new_h = max(cy + ch, ry + rh) - new_y
                current = TextRegion(
                    text=current.text + " " + r.text,
                    bbox=(new_x, new_y, new_w, new_h),
                    confidence=(current.confidence + r.confidence) / 2,
                )
            else:
                merged.append(current)
                current = r
        merged.append(current)
        return merged
