"""
Story Analyzer — uses LLM to understand manga narrative, identify characters,
extract scene descriptions, generate Hindi explanations, and create camera cues.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from openai import AsyncOpenAI

from app.core.config import settings
from app.core.logging import get_logger
from app.services.ai.ocr import PageOCRResult

log = get_logger(__name__)


_client: "AsyncOpenAI | None" = None


def _get_client() -> AsyncOpenAI:
    global _client
    if _client is None:
        if not settings.openai_api_key:
            raise RuntimeError("OPENAI_API_KEY is not set. Please add it to your .env file.")
        _client = AsyncOpenAI(api_key=settings.openai_api_key)
    return _client


# ─────────────────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CharacterInfo:
    name: str
    aliases: List[str] = field(default_factory=list)
    description: str = ""
    personality: List[str] = field(default_factory=list)
    relationships: Dict[str, str] = field(default_factory=dict)

@dataclass
class SceneInfo:
    page_indices: List[int]
    title: str
    setting: str
    mood: str
    characters_present: List[str]
    summary_hindi: str          # Hindi explanation for narration
    summary_english: str
    dialogue_lines: List[Dict]  # [{speaker, text, hindi_translation}]
    camera_cues: List[Dict]     # [{type, params}]  zoom/pan/cut etc.
    emotion_tags: List[str]
    sound_effect_hints: List[str]

@dataclass
class StoryAnalysis:
    series_title: str
    chapter_hint: str
    genre: List[str]
    overall_summary_hindi: str
    overall_summary_english: str
    characters: List[CharacterInfo]
    scenes: List[SceneInfo]
    reading_time_estimate: int    # seconds
    pacing: str                   # slow | medium | fast


# ─────────────────────────────────────────────────────────────────────────────
# System prompts
# ─────────────────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are a manga expert and Hindi content creator.
Your job is to analyze manga pages and produce structured JSON output.

Rules:
- All explanations (summary_hindi, dialogue hindi_translation) must be in natural conversational Hindi
- Be engaging and entertaining, like a YouTube narrator
- Identify all characters and their relationships
- Suggest camera movements: zoom_in, zoom_out, pan_left, pan_right, shake, flash
- Suggest emotions: excited, tense, sad, funny, mysterious, action
- Suggest sound effects: punch, explosion, dramatic_music, silence, crowd_cheer
- Keep Hindi explanations concise but vivid (max 3-4 sentences per scene)
- Return ONLY valid JSON, no markdown code blocks
"""

ANALYSIS_PROMPT_TEMPLATE = """
Analyze these manga pages (OCR text extracted from {total_pages} pages):

OCR TEXT PER PAGE:
{ocr_text}

Known characters from memory:
{known_characters}

Return a JSON object with this exact structure:
{{
  "series_title": "string or 'Unknown'",
  "chapter_hint": "string",
  "genre": ["action","comedy","..."],
  "overall_summary_hindi": "Hindi string",
  "overall_summary_english": "English string",
  "reading_time_estimate": 120,
  "pacing": "medium",
  "characters": [
    {{
      "name": "string",
      "aliases": [],
      "description": "string",
      "personality": ["trait1"],
      "relationships": {{"other_char": "rival/friend/..."}}
    }}
  ],
  "scenes": [
    {{
      "page_indices": [0,1,2],
      "title": "Scene title",
      "setting": "description of location",
      "mood": "tense",
      "characters_present": ["Goku"],
      "summary_hindi": "Hindi narration",
      "summary_english": "English summary",
      "dialogue_lines": [
        {{"speaker": "Goku", "text": "original text", "hindi_translation": "Hindi"}}
      ],
      "camera_cues": [
        {{"type": "zoom_in", "target": "character_face", "duration": 1.5}},
        {{"type": "pan_right", "speed": "slow", "duration": 2.0}}
      ],
      "emotion_tags": ["excited","tense"],
      "sound_effect_hints": ["dramatic_music"]
    }}
  ]
}}
"""


# ─────────────────────────────────────────────────────────────────────────────
# Service
# ─────────────────────────────────────────────────────────────────────────────

class StoryAnalyzer:

    async def analyze(
        self,
        ocr_results: List[PageOCRResult],
        known_characters: Optional[List[Dict]] = None,
    ) -> StoryAnalysis:
        log.info("story_analyzer.start", pages=len(ocr_results))

        ocr_text = self._format_ocr(ocr_results)
        known_chars_str = json.dumps(known_characters or [], ensure_ascii=False, indent=2)

        prompt = ANALYSIS_PROMPT_TEMPLATE.format(
            total_pages=len(ocr_results),
            ocr_text=ocr_text,
            known_characters=known_chars_str,
        )

        raw = await self._call_llm(prompt)
        data = self._safe_parse(raw)
        analysis = self._build_analysis(data)

        log.info(
            "story_analyzer.done",
            scenes=len(analysis.scenes),
            characters=len(analysis.characters),
        )
        return analysis

    async def _call_llm(self, user_prompt: str) -> str:
        response = await _get_client().chat.completions.create(
            model=settings.openai_model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.4,
            max_tokens=4000,
            response_format={"type": "json_object"},
        )
        return response.choices[0].message.content

    def _format_ocr(self, results: List[PageOCRResult]) -> str:
        lines = []
        for r in results:
            lines.append(f"[Page {r.page_index}]: {r.full_text[:500]}")
        return "\n".join(lines)

    def _safe_parse(self, raw: str) -> dict:
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            # Strip markdown fences if present
            import re
            clean = re.sub(r"```(?:json)?|```", "", raw).strip()
            return json.loads(clean)

    def _build_analysis(self, data: dict) -> StoryAnalysis:
        characters = [
            CharacterInfo(**{k: v for k, v in c.items() if k in CharacterInfo.__dataclass_fields__})
            for c in data.get("characters", [])
        ]
        scenes = []
        for s in data.get("scenes", []):
            scenes.append(SceneInfo(
                page_indices=s.get("page_indices", []),
                title=s.get("title", ""),
                setting=s.get("setting", ""),
                mood=s.get("mood", "neutral"),
                characters_present=s.get("characters_present", []),
                summary_hindi=s.get("summary_hindi", ""),
                summary_english=s.get("summary_english", ""),
                dialogue_lines=s.get("dialogue_lines", []),
                camera_cues=s.get("camera_cues", []),
                emotion_tags=s.get("emotion_tags", []),
                sound_effect_hints=s.get("sound_effect_hints", []),
            ))
        return StoryAnalysis(
            series_title=data.get("series_title", "Unknown"),
            chapter_hint=data.get("chapter_hint", ""),
            genre=data.get("genre", []),
            overall_summary_hindi=data.get("overall_summary_hindi", ""),
            overall_summary_english=data.get("overall_summary_english", ""),
            characters=characters,
            scenes=scenes,
            reading_time_estimate=data.get("reading_time_estimate", 120),
            pacing=data.get("pacing", "medium"),
        )

    async def generate_youtube_description(self, analysis: StoryAnalysis) -> str:
        prompt = f"""Create a YouTube video description in Hindi for a manga explanation video.
Manga: {analysis.series_title}
Summary: {analysis.overall_summary_hindi}
Characters: {', '.join(c.name for c in analysis.characters)}
Include: hook, timestamps, hashtags. Keep it engaging."""
        resp = await _get_client().chat.completions.create(
            model=settings.openai_model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=800,
        )
        return resp.choices[0].message.content
