"""
Manga Extractor — converts uploaded file into ordered list of page images.
Supports: PDF, CBZ, ZIP, RAR, 7z, CBR, image folders.
"""
from __future__ import annotations

import os
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import List, Optional

import fitz  # PyMuPDF
import patoolib
from PIL import Image

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)

SUPPORTED_IMG = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}


class MangaExtractor:
    """
    Extract manga pages from any supported archive/document format.
    Returns sorted list of absolute image paths.
    """

    def __init__(self, work_dir: Optional[str] = None):
        self.work_dir = Path(work_dir or settings.temp_dir)
        self.work_dir.mkdir(parents=True, exist_ok=True)

    # ─────────────────────────────────────────────────────────────────────────

    def extract(self, source_path: str, job_id: str) -> List[str]:
        src = Path(source_path)
        out_dir = self.work_dir / job_id / "pages"
        out_dir.mkdir(parents=True, exist_ok=True)

        suffix = src.suffix.lower()

        log.info("extractor.start", source=str(src), suffix=suffix)

        if suffix == ".pdf":
            pages = self._extract_pdf(src, out_dir)
        elif suffix in {".cbz", ".zip"}:
            pages = self._extract_zip(src, out_dir)
        elif suffix in {".cbr", ".rar", ".7z", ".tar"}:
            pages = self._extract_archive(src, out_dir)
        elif suffix in SUPPORTED_IMG:
            pages = [str(src)]
        else:
            raise ValueError(f"Unsupported file type: {suffix}")

        pages = self._sort_pages(pages)
        log.info("extractor.done", pages=len(pages))
        return pages

    # ─────────────────────────────────────────────────────────────────────────

    def _extract_pdf(self, src: Path, out_dir: Path) -> List[str]:
        doc = fitz.open(str(src))
        paths = []
        for i, page in enumerate(doc):
            mat = fitz.Matrix(2.0, 2.0)  # 2x scale → ~150 DPI → ~300 DPI
            pix = page.get_pixmap(matrix=mat, alpha=False)
            img_path = out_dir / f"page_{i:04d}.png"
            pix.save(str(img_path))
            paths.append(str(img_path))
        doc.close()
        return paths

    def _extract_zip(self, src: Path, out_dir: Path) -> List[str]:
        with zipfile.ZipFile(src, "r") as zf:
            zf.extractall(out_dir)
        return self._collect_images(out_dir)

    def _extract_archive(self, src: Path, out_dir: Path) -> List[str]:
        try:
            patoolib.extract_archive(str(src), outdir=str(out_dir))
        except Exception as e:
            log.error("extractor.archive_failed", error=str(e))
            raise
        return self._collect_images(out_dir)

    def _collect_images(self, directory: Path) -> List[str]:
        images = []
        for root, _, files in os.walk(directory):
            for f in files:
                if Path(f).suffix.lower() in SUPPORTED_IMG:
                    images.append(os.path.join(root, f))
        return images

    def _sort_pages(self, paths: List[str]) -> List[str]:
        """Natural sort so page_10 comes after page_9."""
        import re

        def _key(p: str):
            parts = re.split(r"(\d+)", Path(p).stem)
            return [int(x) if x.isdigit() else x.lower() for x in parts]

        return sorted(paths, key=_key)

    # ─────────────────────────────────────────────────────────────────────────

    def normalize_page(self, img_path: str, target_width: int = 1280) -> str:
        """Resize page to consistent width, keeping aspect ratio."""
        img = Image.open(img_path).convert("RGB")
        w, h = img.size
        if w != target_width:
            ratio = target_width / w
            img = img.resize((target_width, int(h * ratio)), Image.LANCZOS)
        img.save(img_path, "PNG", optimize=True)
        return img_path

    def cleanup(self, job_id: str) -> None:
        job_dir = self.work_dir / job_id
        if job_dir.exists():
            shutil.rmtree(job_dir)
            log.info("extractor.cleanup", job_id=job_id)
