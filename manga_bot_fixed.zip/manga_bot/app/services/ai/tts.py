"""
TTS Service — converts Hindi text to speech audio files.
Supports: gTTS (free), ElevenLabs (premium), Coqui TTS (local GPU).
"""
from __future__ import annotations

import asyncio
import os
import tempfile
from pathlib import Path
from typing import List, Optional

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)

VOICE_PRESETS = {
    "female": {"elevenlabs_voice_id": "EXAVITQu4vr4xnSDxMaL", "gtts_tld": "co.in"},
    "male":   {"elevenlabs_voice_id": "VR6AewLTigWG4xSOukaG", "gtts_tld": "co.in"},
    "narrator": {"elevenlabs_voice_id": "onwK4e9ZLuTAKqWW03F9", "gtts_tld": "co.in"},
}


class TTSService:
    def __init__(self, engine: Optional[str] = None, voice_mode: str = "female"):
        self.engine = engine or settings.tts_engine
        self.voice_mode = voice_mode
        self.lang = settings.gtts_lang

    async def synthesize(self, text: str, output_path: str) -> str:
        """Convert text → audio file. Returns path."""
        log.debug("tts.synthesize", engine=self.engine, chars=len(text))
        if self.engine == "gtts":
            return await self._gtts(text, output_path)
        elif self.engine == "elevenlabs":
            return await self._elevenlabs(text, output_path)
        elif self.engine == "coqui":
            return await self._coqui(text, output_path)
        else:
            return await self._gtts(text, output_path)

    async def synthesize_lines(
        self, lines: List[str], work_dir: str
    ) -> List[str]:
        """Synthesize multiple lines, returns list of audio paths."""
        tasks = []
        paths = []
        for i, line in enumerate(lines):
            out = os.path.join(work_dir, f"narration_{i:04d}.mp3")
            paths.append(out)
            tasks.append(self.synthesize(line, out))
        await asyncio.gather(*tasks)
        return paths

    # ─────────────────────────────────────────────────────────────────────────

    async def _gtts(self, text: str, output_path: str) -> str:
        from gtts import gTTS
        preset = VOICE_PRESETS.get(self.voice_mode, VOICE_PRESETS["female"])
        tld = preset["gtts_tld"]
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            None,
            lambda: gTTS(text=text, lang=self.lang, tld=tld, slow=False).save(output_path)
        )
        return output_path

    async def _elevenlabs(self, text: str, output_path: str) -> str:
        from elevenlabs import AsyncElevenLabs, VoiceSettings
        preset = VOICE_PRESETS.get(self.voice_mode, VOICE_PRESETS["female"])
        el = AsyncElevenLabs(api_key=settings.elevenlabs_api_key)
        audio_iter = await el.generate(
            text=text,
            voice=preset["elevenlabs_voice_id"],
            model="eleven_multilingual_v2",
            voice_settings=VoiceSettings(stability=0.5, similarity_boost=0.75),
        )
        with open(output_path, "wb") as f:
            async for chunk in audio_iter:
                f.write(chunk)
        return output_path

    async def _coqui(self, text: str, output_path: str) -> str:
        """
        Coqui TTS — runs locally, GPU accelerated if available.
        Falls back to gtts on error.
        """
        try:
            from TTS.api import TTS as CoquiTTS
            loop = asyncio.get_event_loop()
            def _run():
                tts = CoquiTTS("tts_models/multilingual/multi-dataset/xtts_v2",
                               gpu=settings.gpu_enabled)
                tts.tts_to_file(
                    text=text,
                    language="hi",
                    file_path=output_path,
                )
            await loop.run_in_executor(None, _run)
            return output_path
        except Exception as e:
            log.warning("tts.coqui_failed", error=str(e), fallback="gtts")
            return await self._gtts(text, output_path)

    @staticmethod
    def get_audio_duration(audio_path: str) -> float:
        """Return duration in seconds using pydub."""
        from pydub import AudioSegment
        seg = AudioSegment.from_file(audio_path)
        return len(seg) / 1000.0
