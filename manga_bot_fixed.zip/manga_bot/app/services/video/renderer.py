"""
Video Renderer — assembles scene clips + audio + subtitles into final MP4.
Handles: scene concatenation, audio mixing, title card, outro, quality presets.
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Callable, List, Optional

from app.core.config import settings
from app.core.logging import get_logger
from app.services.ai.story_analyzer import SceneInfo, StoryAnalysis
from app.services.ai.tts import TTSService
from app.services.video.animator import AnimationClip, PanelAnimator
from app.services.video.subtitles import SubtitleEvent, SubtitleRenderer

log = get_logger(__name__)


class VideoRenderer:
    def __init__(
        self,
        quality: str = "720p",
        voice_mode: str = "female",
        tts_engine: str = "gtts",
        subtitle_style: str = "dynamic",
    ):
        self.quality = quality
        self.voice_mode = voice_mode
        self.tts_engine = tts_engine
        self.subtitle_style = subtitle_style
        self.q = settings.quality_presets[quality]
        self.fps = 24

    async def render(
        self,
        analysis: StoryAnalysis,
        page_images: List[str],
        work_dir: str,
        output_path: str,
        progress_cb: Optional[Callable[[float, str], None]] = None,
        resume_artifacts: Optional[dict] = None,
    ) -> str:
        """Full pipeline: TTS → animate → concat → subtitles → final encode."""

        def _progress(pct: float, msg: str):
            if progress_cb:
                progress_cb(pct, msg)
            log.info("render.progress", pct=pct, step=msg)

        work = Path(work_dir)
        tts   = TTSService(engine=self.tts_engine, voice_mode=self.voice_mode)
        anim  = PanelAnimator(quality=self.quality, fps=self.fps)
        subr  = SubtitleRenderer()

        artifacts = resume_artifacts or {}

        # ── Step 1: TTS per scene ─────────────────────────────────────────
        _progress(5, "Generating Hindi narration…")
        scene_audio_paths = artifacts.get("scene_audio", [])

        if not scene_audio_paths:
            audio_dir = work / "audio"
            audio_dir.mkdir(exist_ok=True)
            scene_audio_paths = []
            for i, scene in enumerate(analysis.scenes):
                narration_text = scene.summary_hindi
                if scene.dialogue_lines:
                    hindi_dialogues = " ".join(
                        d.get("hindi_translation", "") for d in scene.dialogue_lines
                    )
                    narration_text = f"{narration_text} {hindi_dialogues}"

                audio_out = str(audio_dir / f"scene_{i:04d}.mp3")
                await tts.synthesize(narration_text, audio_out)
                scene_audio_paths.append(audio_out)
                _progress(5 + (i / len(analysis.scenes)) * 25, f"TTS: scene {i+1}")

            artifacts["scene_audio"] = scene_audio_paths

        # ── Step 2: Animate panels ────────────────────────────────────────
        _progress(30, "Animating manga panels…")
        scene_video_paths = artifacts.get("scene_video", [])

        if not scene_video_paths:
            video_dir = work / "clips"
            video_dir.mkdir(exist_ok=True)
            scene_video_paths = []

            for i, scene in enumerate(analysis.scenes):
                dur = tts.get_audio_duration(scene_audio_paths[i])
                clip_out = str(video_dir / f"scene_{i:04d}.mp4")
                clip = anim.animate_scene(scene, page_images, dur, clip_out)
                scene_video_paths.append(clip.output_path)
                _progress(30 + (i / len(analysis.scenes)) * 30, f"Animating: scene {i+1}")

            artifacts["scene_video"] = scene_video_paths

        # ── Step 3: Merge audio into clips ───────────────────────────────
        _progress(60, "Merging audio with video clips…")
        merged_paths = artifacts.get("merged_clips", [])

        if not merged_paths:
            merged_dir = work / "merged"
            merged_dir.mkdir(exist_ok=True)
            merged_paths = []

            for i, (vp, ap) in enumerate(zip(scene_video_paths, scene_audio_paths)):
                out = str(merged_dir / f"merged_{i:04d}.mp4")
                self._merge_av(vp, ap, out)
                merged_paths.append(out)

            artifacts["merged_clips"] = merged_paths

        # ── Step 4: Add title card ────────────────────────────────────────
        _progress(70, "Adding title card…")
        title_clip = str(work / "title.mp4")
        if not os.path.exists(title_clip):
            self._make_title_card(analysis.series_title, analysis.overall_summary_hindi[:80], title_clip)

        # ── Step 5: Concatenate all clips ─────────────────────────────────
        _progress(75, "Concatenating scenes…")
        concat_path = str(work / "concat.mp4")
        all_clips = [title_clip] + merged_paths
        self._concat_clips(all_clips, concat_path)

        # ── Step 6: Build subtitle file ───────────────────────────────────
        _progress(85, "Building subtitles…")
        subtitle_events = self._build_subtitle_events(
            analysis, scene_audio_paths, title_duration=3.0
        )
        ass_path = str(work / "subtitles.ass")
        w, h = self.q["width"], self.q["height"]
        subr.events_to_ass(subtitle_events, ass_path, self.subtitle_style, (w, h))

        # Also export SRT
        subr.events_to_srt(subtitle_events, str(work / "subtitles.srt"))

        # ── Step 7: Burn subtitles ────────────────────────────────────────
        _progress(90, "Burning subtitles…")
        subr.burn_subtitles(concat_path, ass_path, output_path)

        _progress(100, "Done!")
        log.info("render.complete", output=output_path)
        return output_path

    # ─────────────────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _merge_av(self, video: str, audio: str, output: str) -> None:
        cmd = (
            f"ffmpeg -y "
            f"-i {video} -i {audio} "
            f"-c:v copy -c:a aac -b:a 128k "
            f"-shortest {output} -loglevel error"
        )
        os.system(cmd)

    def _concat_clips(self, clips: List[str], output: str) -> None:
        list_file = output + ".list.txt"
        with open(list_file, "w") as f:
            for c in clips:
                f.write(f"file '{c}'\n")
        cmd = (
            f"ffmpeg -y -f concat -safe 0 "
            f"-i {list_file} "
            f"-c copy {output} -loglevel error"
        )
        os.system(cmd)
        os.remove(list_file)

    def _make_title_card(self, title: str, subtitle: str, output: str, duration: float = 3.0) -> None:
        w, h = self.q["width"], self.q["height"]
        cmd = (
            f"ffmpeg -y "
            f"-f lavfi -i color=black:size={w}x{h}:rate={self.fps}:duration={duration} "
            f"-vf \"drawtext=text='{self._esc(title)}':fontcolor=white:fontsize=48:"
            f"x=(w-text_w)/2:y=(h-text_h)/2-40,"
            f"drawtext=text='{self._esc(subtitle)}':fontcolor=yellow:fontsize=24:"
            f"x=(w-text_w)/2:y=(h-text_h)/2+40\" "
            f"-c:v libx264 -pix_fmt yuv420p {output} -loglevel error"
        )
        os.system(cmd)

    def _esc(self, text: str) -> str:
        return text.replace("'", "\\'").replace(":", "\\:")[:60]

    def _build_subtitle_events(
        self,
        analysis: StoryAnalysis,
        audio_paths: List[str],
        title_duration: float = 3.0,
    ) -> List[SubtitleEvent]:
        from app.services.ai.tts import TTSService
        events = []
        cursor = title_duration
        for i, (scene, ap) in enumerate(zip(analysis.scenes, audio_paths)):
            dur = TTSService.get_audio_duration(ap)
            narrations = SubtitleRenderer._split_text(scene.summary_hindi, 35)
            chunk_dur = dur / max(len(narrations), 1)
            for j, chunk in enumerate(narrations):
                events.append(SubtitleEvent(
                    start_sec=cursor + j * chunk_dur,
                    end_sec=cursor + (j + 1) * chunk_dur,
                    text=chunk,
                ))
            cursor += dur
        return events
