"""
Panel Animator — applies cinematic camera movements to static manga panels.
Effects: Ken Burns zoom, pan, shake, flash, fade, speed ramp.
Outputs per-scene video clips (no audio).
"""
from __future__ import annotations

import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

from app.core.config import settings
from app.core.logging import get_logger
from app.services.ai.story_analyzer import SceneInfo

log = get_logger(__name__)

QUALITY_MAP = {
    "480p":  (854,  480),
    "720p":  (1280, 720),
    "1080p": (1920, 1080),
}


@dataclass
class AnimationClip:
    scene_index: int
    output_path: str
    duration: float


class PanelAnimator:
    def __init__(self, quality: str = "720p", fps: int = 24):
        self.quality = quality
        self.fps = fps
        self.w, self.h = QUALITY_MAP.get(quality, (1280, 720))

    # ─────────────────────────────────────────────────────────────────────────

    def animate_scene(
        self,
        scene: SceneInfo,
        page_images: List[str],
        narration_duration: float,
        output_path: str,
    ) -> AnimationClip:
        """
        Animate all pages for a scene into a single video clip.
        Duration is driven by narration audio length.
        """
        pages_in_scene = [page_images[i] for i in scene.page_indices if i < len(page_images)]
        if not pages_in_scene:
            pages_in_scene = [page_images[0]] if page_images else []

        per_page_dur = narration_duration / max(len(pages_in_scene), 1)
        clip_dur = per_page_dur * len(pages_in_scene)

        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        tmp_path = output_path.replace(".mp4", "_tmp.mp4")
        writer = cv2.VideoWriter(tmp_path, fourcc, self.fps, (self.w, self.h))

        cue_index = 0
        for page_path in pages_in_scene:
            img = self._load_and_fit(page_path)
            cues = scene.camera_cues[cue_index: cue_index + 2] if scene.camera_cues else []
            cue_index += len(cues)
            frames = self._render_page_frames(img, per_page_dur, cues, scene.mood)
            for frame in frames:
                writer.write(frame)

        writer.release()

        # Re-encode with FFmpeg for proper codec
        self._ffmpeg_encode(tmp_path, output_path)
        os.remove(tmp_path)

        log.info("animator.scene_done", scene=scene.title, dur=clip_dur)
        return AnimationClip(
            scene_index=0,
            output_path=output_path,
            duration=clip_dur,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Frame generators
    # ─────────────────────────────────────────────────────────────────────────

    def _render_page_frames(
        self,
        img: np.ndarray,
        duration: float,
        cues: List[Dict],
        mood: str,
    ) -> List[np.ndarray]:
        total_frames = int(duration * self.fps)
        if not cues:
            cues = [self._default_cue(mood)]

        frames = []
        cue = cues[0]
        cue_type = cue.get("type", "zoom_in")

        for f in range(total_frames):
            t = f / max(total_frames - 1, 1)  # 0.0 → 1.0
            frame = self._apply_cue(img, cue_type, t, cue)
            frame = self._apply_mood_filter(frame, mood)
            frames.append(frame)

        return frames

    def _apply_cue(
        self, img: np.ndarray, cue_type: str, t: float, params: Dict
    ) -> np.ndarray:
        h, w = img.shape[:2]

        if cue_type == "zoom_in":
            scale_start = 1.0
            scale_end = params.get("scale_end", 1.3)
            scale = scale_start + (scale_end - scale_start) * self._ease(t)
            return self._crop_zoom(img, scale, cx=0.5, cy=0.5)

        elif cue_type == "zoom_out":
            scale_start = params.get("scale_start", 1.3)
            scale_end = 1.0
            scale = scale_start + (scale_end - scale_start) * self._ease(t)
            return self._crop_zoom(img, scale, cx=0.5, cy=0.5)

        elif cue_type == "pan_right":
            cx = 0.3 + 0.4 * self._ease(t)
            return self._crop_zoom(img, 1.15, cx=cx, cy=0.5)

        elif cue_type == "pan_left":
            cx = 0.7 - 0.4 * self._ease(t)
            return self._crop_zoom(img, 1.15, cx=cx, cy=0.5)

        elif cue_type == "pan_up":
            cy = 0.7 - 0.4 * self._ease(t)
            return self._crop_zoom(img, 1.15, cx=0.5, cy=cy)

        elif cue_type == "pan_down":
            cy = 0.3 + 0.4 * self._ease(t)
            return self._crop_zoom(img, 1.15, cx=0.5, cy=cy)

        elif cue_type == "shake":
            intensity = params.get("intensity", 8)
            dx = int(np.random.uniform(-intensity, intensity))
            dy = int(np.random.uniform(-intensity, intensity))
            M = np.float32([[1, 0, dx], [0, 1, dy]])
            shaken = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
            return self._fit_to_output(shaken)

        elif cue_type == "flash":
            frame = self._fit_to_output(img)
            if t < 0.1:
                brightness = int(200 * (1 - t / 0.1))
                frame = cv2.add(frame, np.full_like(frame, brightness))
            return frame

        elif cue_type == "static":
            return self._fit_to_output(img)

        else:
            return self._fit_to_output(img)

    def _crop_zoom(
        self, img: np.ndarray, scale: float, cx: float, cy: float
    ) -> np.ndarray:
        h, w = img.shape[:2]
        nw = int(w / scale)
        nh = int(h / scale)
        x1 = int(max(0, cx * w - nw / 2))
        y1 = int(max(0, cy * h - nh / 2))
        x2 = min(w, x1 + nw)
        y2 = min(h, y1 + nh)
        cropped = img[y1:y2, x1:x2]
        return cv2.resize(cropped, (self.w, self.h), interpolation=cv2.INTER_LANCZOS4)

    def _fit_to_output(self, img: np.ndarray) -> np.ndarray:
        return cv2.resize(img, (self.w, self.h), interpolation=cv2.INTER_LANCZOS4)

    # ─────────────────────────────────────────────────────────────────────────
    # Mood filters
    # ─────────────────────────────────────────────────────────────────────────

    def _apply_mood_filter(self, frame: np.ndarray, mood: str) -> np.ndarray:
        if mood in ("tense", "action"):
            # Slight red tint + contrast boost
            frame = frame.astype(np.float32)
            frame[:, :, 2] = np.clip(frame[:, :, 2] * 1.1, 0, 255)
            frame = np.clip(frame * 1.05 - 5, 0, 255).astype(np.uint8)
        elif mood in ("sad", "melancholy"):
            # Desaturate
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            frame = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
            frame = cv2.addWeighted(frame, 0.6, cv2.cvtColor(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), cv2.COLOR_GRAY2BGR), 0.4, 0)
        elif mood in ("funny", "comedy"):
            # Slightly saturated + bright
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV).astype(np.float32)
            hsv[:, :, 1] = np.clip(hsv[:, :, 1] * 1.2, 0, 255)
            frame = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)
        return frame

    # ─────────────────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _load_and_fit(self, path: str) -> np.ndarray:
        img = cv2.imread(path)
        if img is None:
            img = np.ones((self.h, self.w, 3), dtype=np.uint8) * 220
        # Letterbox to output size
        h, w = img.shape[:2]
        scale = min(self.w / w, self.h / h)
        nw, nh = int(w * scale), int(h * scale)
        resized = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LANCZOS4)
        canvas = np.ones((self.h, self.w, 3), dtype=np.uint8) * 255
        y_off = (self.h - nh) // 2
        x_off = (self.w - nw) // 2
        canvas[y_off:y_off+nh, x_off:x_off+nw] = resized
        return canvas

    def _ease(self, t: float) -> float:
        """Smooth ease-in-out."""
        return t * t * (3 - 2 * t)

    def _default_cue(self, mood: str) -> Dict:
        mood_cues = {
            "action": {"type": "shake", "intensity": 6},
            "tense":  {"type": "zoom_in", "scale_end": 1.25},
            "sad":    {"type": "pan_down", "speed": "slow"},
            "funny":  {"type": "zoom_out", "scale_start": 1.2},
        }
        return mood_cues.get(mood, {"type": "zoom_in", "scale_end": 1.15})

    def _ffmpeg_encode(self, src: str, dst: str) -> None:
        quality = settings.quality_presets[self.quality]
        gpu_flags = "-c:v h264_nvenc -preset fast" if settings.gpu_enabled else f"-c:v libx264 -crf {quality['crf']}"
        cmd = (
            f"ffmpeg -y -i {src} "
            f"{gpu_flags} "
            f"-vf scale={self.w}:{self.h} "
            f"-r {self.fps} "
            f"-pix_fmt yuv420p "
            f"-threads {settings.ffmpeg_threads} "
            f"{dst} -loglevel error"
        )
        os.system(cmd)
