"""
Subtitle Renderer — generates ASS/SRT subtitles and burns them into video.
Supports: dynamic pop-in, karaoke-style, static bottom, floating.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List, Optional

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


@dataclass
class SubtitleEvent:
    start_sec: float
    end_sec: float
    text: str
    style: str = "Default"


class SubtitleRenderer:

    STYLES = {
        "dynamic": {
            "fontname": "Noto Sans Devanagari",
            "fontsize": 32,
            "primary_colour": "&H00FFFFFF",
            "outline_colour": "&H00000000",
            "back_colour": "&H80000000",
            "bold": 1,
            "outline": 3,
            "shadow": 1,
            "alignment": 2,         # bottom-center
            "margin_v": 40,
        },
        "cinema": {
            "fontname": "Noto Sans Devanagari",
            "fontsize": 28,
            "primary_colour": "&H00FFFF00",  # yellow
            "outline_colour": "&H00000000",
            "bold": 0,
            "outline": 2,
            "alignment": 2,
            "margin_v": 30,
        },
        "minimal": {
            "fontname": "Noto Sans Devanagari",
            "fontsize": 24,
            "primary_colour": "&H00FFFFFF",
            "outline_colour": "&H00000000",
            "bold": 0,
            "outline": 1,
            "alignment": 2,
            "margin_v": 20,
        },
    }

    def events_to_ass(
        self,
        events: List[SubtitleEvent],
        output_path: str,
        style: str = "dynamic",
        resolution: tuple = (1280, 720),
    ) -> str:
        """Write ASS subtitle file."""
        s = self.STYLES.get(style, self.STYLES["dynamic"])
        w, h = resolution

        header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {w}
PlayResY: {h}
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.601

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{s['fontname']},{s['fontsize']},{s.get('primary_colour','&H00FFFFFF')},&H000000FF,{s.get('outline_colour','&H00000000')},{s.get('back_colour','&H80000000')},{s.get('bold',0)},0,0,0,100,100,0,0,1,{s.get('outline',2)},{s.get('shadow',1)},{s.get('alignment',2)},10,10,{s.get('margin_v',40)},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
        event_lines = []
        for ev in events:
            start = self._fmt_time(ev.start_sec)
            end   = self._fmt_time(ev.end_sec)
            text  = ev.text.replace("\n", "\\N")
            if style == "dynamic":
                # Pop-in effect via ASS override tags
                text = r"{\fad(150,150)\blur3}" + text
            event_lines.append(f"Dialogue: 0,{start},{end},Default,,0,0,0,,{text}")

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(header + "\n".join(event_lines) + "\n")

        log.debug("subtitles.ass_written", path=output_path, events=len(events))
        return output_path

    def events_to_srt(self, events: List[SubtitleEvent], output_path: str) -> str:
        lines = []
        for i, ev in enumerate(events, 1):
            lines.append(str(i))
            lines.append(f"{self._fmt_srt(ev.start_sec)} --> {self._fmt_srt(ev.end_sec)}")
            lines.append(ev.text)
            lines.append("")
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        return output_path

    def burn_subtitles(
        self,
        video_path: str,
        ass_path: str,
        output_path: str,
    ) -> str:
        """Burn ASS subs into video using FFmpeg."""
        # Escape path for FFmpeg filter
        safe_ass = ass_path.replace("\\", "/").replace(":", "\\:")
        cmd = (
            f"ffmpeg -y -i {video_path} "
            f"-vf \"ass={safe_ass}\" "
            f"-c:v libx264 -crf 20 "
            f"-c:a copy "
            f"-threads {settings.ffmpeg_threads} "
            f"{output_path} -loglevel error"
        )
        ret = os.system(cmd)
        if ret != 0:
            log.error("subtitles.burn_failed", cmd=cmd)
            raise RuntimeError("FFmpeg subtitle burn failed")
        log.info("subtitles.burned", output=output_path)
        return output_path

    # ─────────────────────────────────────────────────────────────────────────

    def _fmt_time(self, seconds: float) -> str:
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = seconds % 60
        return f"{h:d}:{m:02d}:{s:05.2f}"

    def _fmt_srt(self, seconds: float) -> str:
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = int(seconds % 60)
        ms = int((seconds - int(seconds)) * 1000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    @staticmethod
    def build_events_from_analysis(
        scene_narrations: List[dict],
    ) -> List[SubtitleEvent]:
        """
        scene_narrations: [{text, start_sec, end_sec}]
        Auto-splits long lines.
        """
        events = []
        for item in scene_narrations:
            text = item["text"]
            start = item["start_sec"]
            end   = item["end_sec"]
            dur   = end - start
            # Split long text into ≤ 40 char chunks
            chunks = SubtitleRenderer._split_text(text, 40)
            chunk_dur = dur / max(len(chunks), 1)
            for i, chunk in enumerate(chunks):
                events.append(SubtitleEvent(
                    start_sec=start + i * chunk_dur,
                    end_sec=start + (i + 1) * chunk_dur,
                    text=chunk,
                ))
        return events

    @staticmethod
    def _split_text(text: str, max_chars: int) -> List[str]:
        words = text.split()
        chunks, current = [], ""
        for w in words:
            if len(current) + len(w) + 1 <= max_chars:
                current = (current + " " + w).strip()
            else:
                if current:
                    chunks.append(current)
                current = w
        if current:
            chunks.append(current)
        return chunks or [text]
