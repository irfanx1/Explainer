"""Async Redis client with helpers for caching and pub/sub."""
from __future__ import annotations

import json
from typing import Any, Optional

import redis.asyncio as aioredis

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)

_redis: Optional[aioredis.Redis] = None


async def get_redis() -> aioredis.Redis:
    global _redis
    if _redis is None:
        _redis = aioredis.from_url(
            settings.redis_url,
            encoding="utf-8",
            decode_responses=True,
        )
    return _redis


async def close_redis() -> None:
    global _redis
    if _redis:
        await _redis.close()
        _redis = None


# ── Convenience helpers ───────────────────────────────────────────────────────

async def cache_set(key: str, value: Any, ttl: int = 3600) -> None:
    r = await get_redis()
    await r.setex(key, ttl, json.dumps(value, default=str))


async def cache_get(key: str) -> Optional[Any]:
    r = await get_redis()
    data = await r.get(key)
    return json.loads(data) if data else None


async def cache_delete(key: str) -> None:
    r = await get_redis()
    await r.delete(key)


async def publish(channel: str, message: dict) -> None:
    r = await get_redis()
    await r.publish(channel, json.dumps(message, default=str))


async def set_job_progress(job_id: str, progress: dict) -> None:
    await cache_set(f"progress:{job_id}", progress, ttl=86400)


async def get_job_progress(job_id: str) -> Optional[dict]:
    return await cache_get(f"progress:{job_id}")
