"""
FastAPI application — REST API for admin panel, webhook, and status endpoints.
"""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api.routes import jobs, admin, health, webhook
from app.core.config import settings
from app.core.database import close_db, init_db
from app.core.logging import get_logger, setup_logging
from app.core.redis_client import close_redis

setup_logging()
log = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("api.startup")
    await init_db()
    yield
    log.info("api.shutdown")
    await close_db()
    await close_redis()


app = FastAPI(
    title="Manga Bot API",
    description="Manga → Animated Hindi Video Pipeline",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs" if settings.is_dev else None,
    redoc_url=None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(health.router,  prefix="/api/v1", tags=["health"])
app.include_router(jobs.router,    prefix="/api/v1", tags=["jobs"])
app.include_router(admin.router,   prefix="/api/v1/admin", tags=["admin"])
app.include_router(webhook.router, prefix="/api/v1", tags=["webhook"])

log.info("api.ready")
