"""Telegram webhook endpoint (alternative to polling)."""
from __future__ import annotations

from fastapi import APIRouter, Request, Response
from telegram import Update

from app.core.config import settings
from app.core.logging import get_logger

router = APIRouter()
log = get_logger(__name__)

_app = None  # lazily set


def set_telegram_app(telegram_application):
    global _app
    _app = telegram_application


@router.post("/webhook")
async def telegram_webhook(request: Request):
    if _app is None:
        return Response(status_code=503)
    body = await request.json()
    update = Update.de_json(body, _app.bot)
    await _app.process_update(update)
    return Response(status_code=200)


@router.get("/webhook/info")
async def webhook_info():
    return {"mode": "webhook", "token_set": bool(settings.telegram_bot_token)}
