"""Jobs REST API."""
from __future__ import annotations

import uuid
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select, desc

from app.core.database import AsyncSessionLocal
from app.core.redis_client import get_job_progress
from app.models.job import Job, JobStatus

router = APIRouter()


class JobResponse(BaseModel):
    id: str
    status: str
    progress_pct: float
    current_step: Optional[str]
    original_filename: Optional[str]
    quality: str
    created_at: str
    output_url: Optional[str]
    youtube_url: Optional[str]
    error_message: Optional[str]

    class Config:
        from_attributes = True


@router.get("/jobs/{job_id}", response_model=JobResponse)
async def get_job(job_id: str):
    try:
        uid = uuid.UUID(job_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid job ID")

    async with AsyncSessionLocal() as db:
        result = await db.execute(select(Job).where(Job.id == uid))
        job = result.scalar_one_or_none()

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # Merge live Redis progress
    live = await get_job_progress(job_id)
    pct = live["pct"] if live else job.progress_pct
    step = live["step"] if live else job.current_step

    return JobResponse(
        id=str(job.id),
        status=job.status.value,
        progress_pct=pct,
        current_step=step,
        original_filename=job.original_filename,
        quality=job.quality,
        created_at=job.created_at.isoformat(),
        output_url=job.output_url,
        youtube_url=job.youtube_url,
        error_message=job.error_message,
    )


@router.get("/jobs", response_model=List[JobResponse])
async def list_jobs(
    user_id: Optional[int] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(20, le=100),
):
    async with AsyncSessionLocal() as db:
        stmt = select(Job).order_by(desc(Job.created_at)).limit(limit)
        if user_id:
            stmt = stmt.where(Job.user_telegram_id == user_id)
        if status:
            stmt = stmt.where(Job.status == status)
        result = await db.execute(stmt)
        jobs = result.scalars().all()

    return [
        JobResponse(
            id=str(j.id),
            status=j.status.value,
            progress_pct=j.progress_pct,
            current_step=j.current_step,
            original_filename=j.original_filename,
            quality=j.quality,
            created_at=j.created_at.isoformat(),
            output_url=j.output_url,
            youtube_url=j.youtube_url,
            error_message=j.error_message,
        )
        for j in jobs
    ]


@router.delete("/jobs/{job_id}")
async def cancel_job(job_id: str):
    try:
        uid = uuid.UUID(job_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid job ID")

    async with AsyncSessionLocal() as db:
        result = await db.execute(select(Job).where(Job.id == uid))
        job = result.scalar_one_or_none()
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        if job.celery_task_id:
            from app.workers.celery_app import celery_app
            celery_app.control.revoke(job.celery_task_id, terminate=True)
        job.status = JobStatus.CANCELLED
        await db.commit()

    return {"message": "Job cancelled"}
