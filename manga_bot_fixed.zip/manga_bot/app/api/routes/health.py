from fastapi import APIRouter
from app.core.redis_client import get_redis

router = APIRouter()

@router.get("/health")
async def health():
    try:
        r = await get_redis()
        await r.ping()
        redis_ok = True
    except Exception:
        redis_ok = False
    return {"status": "ok", "redis": redis_ok}
