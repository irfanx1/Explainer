"""Admin REST API — protected by basic auth."""
from __future__ import annotations

import secrets
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel
from sqlalchemy import func, select

from app.core.config import settings
from app.core.database import AsyncSessionLocal
from app.models.job import Job, JobStatus
from app.models.user import User

router = APIRouter()
security = HTTPBasic()


def require_admin(credentials: HTTPBasicCredentials = Depends(security)):
    ok_user = secrets.compare_digest(credentials.username, settings.admin_username)
    ok_pass = secrets.compare_digest(credentials.password, settings.admin_password)
    if not (ok_user and ok_pass):
        raise HTTPException(status_code=401, detail="Unauthorized", headers={"WWW-Authenticate": "Basic"})
    return credentials.username


class StatsResponse(BaseModel):
    total_users: int
    total_jobs: int
    completed_jobs: int
    failed_jobs: int
    active_jobs: int


@router.get("/stats", response_model=StatsResponse)
async def admin_stats(_: str = Depends(require_admin)):
    async with AsyncSessionLocal() as db:
        total_users    = (await db.execute(select(func.count(User.id)))).scalar()
        total_jobs     = (await db.execute(select(func.count(Job.id)))).scalar()
        completed_jobs = (await db.execute(select(func.count(Job.id)).where(Job.status == JobStatus.DONE))).scalar()
        failed_jobs    = (await db.execute(select(func.count(Job.id)).where(Job.status == JobStatus.FAILED))).scalar()
        active_jobs    = (await db.execute(
            select(func.count(Job.id)).where(Job.status.not_in([JobStatus.DONE, JobStatus.FAILED, JobStatus.CANCELLED]))
        )).scalar()

    return StatsResponse(
        total_users=total_users,
        total_jobs=total_jobs,
        completed_jobs=completed_jobs,
        failed_jobs=failed_jobs,
        active_jobs=active_jobs,
    )


@router.get("/users")
async def admin_list_users(limit: int = 50, _: str = Depends(require_admin)):
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(User).order_by(User.created_at.desc()).limit(limit))
        users = result.scalars().all()
    return [
        {
            "telegram_id": u.telegram_id,
            "username": u.username,
            "full_name": u.full_name,
            "total_jobs": u.total_jobs,
            "is_banned": u.is_banned,
            "is_admin": u.is_admin,
            "created_at": u.created_at.isoformat(),
        }
        for u in users
    ]


@router.post("/users/{telegram_id}/ban")
async def ban_user(telegram_id: int, _: str = Depends(require_admin)):
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        user.is_banned = True
        await db.commit()
    return {"message": f"User {telegram_id} banned"}


@router.post("/users/{telegram_id}/unban")
async def unban_user(telegram_id: int, _: str = Depends(require_admin)):
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        user.is_banned = False
        await db.commit()
    return {"message": f"User {telegram_id} unbanned"}


@router.get("/jobs")
async def admin_list_jobs(limit: int = 100, status: Optional[str] = None, _: str = Depends(require_admin)):
    async with AsyncSessionLocal() as db:
        stmt = select(Job).order_by(Job.created_at.desc()).limit(limit)
        if status:
            stmt = stmt.where(Job.status == status)
        result = await db.execute(stmt)
        jobs = result.scalars().all()
    return [
        {
            "id": str(j.id),
            "user_telegram_id": j.user_telegram_id,
            "status": j.status.value,
            "progress_pct": j.progress_pct,
            "quality": j.quality,
            "original_filename": j.original_filename,
            "created_at": j.created_at.isoformat(),
            "finished_at": j.finished_at.isoformat() if j.finished_at else None,
            "error_message": j.error_message,
        }
        for j in jobs
    ]
