"""Job history handler."""
from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from app.core.database import AsyncSessionLocal
from app.models.job import Job, JobStatus
from sqlalchemy import select, desc


async def handle_history_command(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    async with AsyncSessionLocal() as db:
        stmt = (
            select(Job)
            .where(Job.user_telegram_id == uid)
            .order_by(desc(Job.created_at))
            .limit(10)
        )
        result = await db.execute(stmt)
        jobs = result.scalars().all()

    if not jobs:
        await update.message.reply_text("No conversion history yet. Send a manga file!")
        return

    lines = ["📜 *Recent Conversions*\n"]
    for job in jobs:
        status_icon = "✅" if job.status == JobStatus.DONE else ("❌" if job.status == JobStatus.FAILED else "⏳")
        dur = f"{int(job.video_duration_seconds // 60)}m {int(job.video_duration_seconds % 60)}s" if job.video_duration_seconds else "—"
        lines.append(
            f"{status_icon} `{str(job.id)[:8]}` | {job.original_filename or 'unknown'}\n"
            f"   🎬 Duration: {dur} | 📅 {job.created_at.strftime('%d %b %Y')}\n"
        )

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
