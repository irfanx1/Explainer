"""Admin panel — stats, user management, job control."""
from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from app.core.config import settings
from app.core.database import AsyncSessionLocal
from app.models.job import Job, JobStatus
from app.models.user import User
from sqlalchemy import func, select


def is_admin(telegram_id: int) -> bool:
    return telegram_id in settings.telegram_admin_ids


async def handle_admin_command(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    if not is_admin(uid):
        await update.message.reply_text("❌ Admin access required.")
        return

    args = ctx.args or []
    sub = args[0] if args else "stats"

    if sub == "stats":
        await _admin_stats(update)
    elif sub == "ban" and len(args) >= 2:
        await _admin_ban(update, int(args[1]))
    elif sub == "unban" and len(args) >= 2:
        await _admin_unban(update, int(args[1]))
    elif sub == "cancel" and len(args) >= 2:
        await _admin_cancel_job(update, args[1])
    elif sub == "users":
        await _admin_list_users(update)
    else:
        await update.message.reply_text(
            "🔧 *Admin Commands*\n\n"
            "/admin stats — System statistics\n"
            "/admin users — List recent users\n"
            "/admin ban <user_id> — Ban user\n"
            "/admin unban <user_id> — Unban user\n"
            "/admin cancel <job_id> — Cancel job\n",
            parse_mode="Markdown",
        )


async def _admin_stats(update: Update) -> None:
    async with AsyncSessionLocal() as db:
        total_users = (await db.execute(select(func.count(User.id)))).scalar()
        total_jobs  = (await db.execute(select(func.count(Job.id)))).scalar()
        done_jobs   = (await db.execute(
            select(func.count(Job.id)).where(Job.status == JobStatus.DONE)
        )).scalar()
        active_jobs = (await db.execute(
            select(func.count(Job.id)).where(Job.status.not_in([
                JobStatus.DONE, JobStatus.FAILED, JobStatus.CANCELLED
            ]))
        )).scalar()

    await update.message.reply_text(
        f"📊 *Admin Dashboard*\n\n"
        f"👥 Total Users: {total_users}\n"
        f"📋 Total Jobs: {total_jobs}\n"
        f"✅ Completed: {done_jobs}\n"
        f"⚡ Active Now: {active_jobs}\n",
        parse_mode="Markdown",
    )


async def _admin_ban(update: Update, target_id: int) -> None:
    async with AsyncSessionLocal() as db:
        stmt = select(User).where(User.telegram_id == target_id)
        result = await db.execute(stmt)
        user = result.scalar_one_or_none()
        if user:
            user.is_banned = True
            await db.commit()
            await update.message.reply_text(f"🔨 User {target_id} banned.")
        else:
            await update.message.reply_text("User not found.")


async def _admin_unban(update: Update, target_id: int) -> None:
    async with AsyncSessionLocal() as db:
        stmt = select(User).where(User.telegram_id == target_id)
        result = await db.execute(stmt)
        user = result.scalar_one_or_none()
        if user:
            user.is_banned = False
            await db.commit()
            await update.message.reply_text(f"✅ User {target_id} unbanned.")
        else:
            await update.message.reply_text("User not found.")


async def _admin_cancel_job(update: Update, job_id: str) -> None:
    import uuid
    from app.core.database import AsyncSessionLocal
    async with AsyncSessionLocal() as db:
        try:
            stmt = select(Job).where(Job.id == uuid.UUID(job_id))
            result = await db.execute(stmt)
            job = result.scalar_one_or_none()
            if job:
                # Revoke Celery task
                if job.celery_task_id:
                    from app.workers.celery_app import celery_app
                    celery_app.control.revoke(job.celery_task_id, terminate=True)
                job.status = JobStatus.CANCELLED
                await db.commit()
                await update.message.reply_text(f"🚫 Job {job_id[:8]} cancelled.")
            else:
                await update.message.reply_text("Job not found.")
        except Exception as e:
            await update.message.reply_text(f"Error: {e}")


async def _admin_list_users(update: Update) -> None:
    async with AsyncSessionLocal() as db:
        stmt = select(User).order_by(User.created_at.desc()).limit(10)
        result = await db.execute(stmt)
        users = result.scalars().all()

    lines = ["👥 *Recent Users*\n"]
    for u in users:
        ban = "🔨" if u.is_banned else "✅"
        lines.append(f"{ban} `{u.telegram_id}` | @{u.username or 'N/A'} | Jobs: {u.total_jobs}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
