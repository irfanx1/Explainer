"""
/convert and document upload handlers.
Saves file, creates DB job, enqueues Celery task.
"""
from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from app.core.config import settings
from app.core.database import AsyncSessionLocal
from app.core.logging import get_logger
from app.models.job import Job, JobStatus
from app.models.user import User
from sqlalchemy import select

log = get_logger(__name__)

ALLOWED_EXTENSIONS = {".pdf", ".cbz", ".cbr", ".zip", ".rar", ".7z"}


async def _upsert_user(telegram_id: int, username: str, full_name: str) -> User:
    async with AsyncSessionLocal() as db:
        stmt = select(User).where(User.telegram_id == telegram_id)
        result = await db.execute(stmt)
        user = result.scalar_one_or_none()
        if not user:
            user = User(
                id=uuid.uuid4(),
                telegram_id=telegram_id,
                username=username,
                full_name=full_name,
                is_admin=telegram_id in settings.telegram_admin_ids,
            )
            db.add(user)
        else:
            user.username = username or user.username
            user.full_name = full_name or user.full_name
        user.last_seen_at = datetime.now(timezone.utc)
        await db.commit()
        await db.refresh(user)
        return user


async def handle_convert_command(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "📤 *Send me your manga file!*\n\n"
        "Supported formats: PDF, CBZ, CBR, ZIP, RAR, 7z\n"
        f"Max size: {settings.upload_max_mb} MB\n\n"
        "Just send the file directly in this chat.",
        parse_mode="Markdown",
    )


async def handle_document_upload(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    doc = update.message.document
    if not doc:
        return

    tg_user = update.effective_user

    # Upsert user with error handling
    try:
        user = await _upsert_user(tg_user.id, tg_user.username or "", tg_user.full_name or "")
    except Exception as e:
        log.error("convert.upsert_user_failed", error=str(e))
        await update.message.reply_text(
            "❌ Database error. Please try again later.\n"
            "Make sure the bot is fully deployed with a running database."
        )
        return

    if user.is_banned:
        await update.message.reply_text("❌ You are banned from using this bot.")
        return

    # File size check
    if doc.file_size > settings.upload_max_bytes:
        await update.message.reply_text(
            f"❌ File too large! Max {settings.upload_max_mb} MB.\n"
            f"Your file: {doc.file_size // (1024*1024)} MB"
        )
        return

    # Extension check
    ext = Path(doc.file_name or "").suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        await update.message.reply_text(
            f"❌ Unsupported file type: `{ext or 'unknown'}`\n"
            f"Supported: {', '.join(sorted(ALLOWED_EXTENSIONS))}",
            parse_mode="Markdown",
        )
        return

    progress_msg = await update.message.reply_text("⬇️ Downloading file…")

    # Download file
    job_id = str(uuid.uuid4())
    try:
        download_dir = Path(settings.temp_dir) / job_id
        download_dir.mkdir(parents=True, exist_ok=True)
        file_path = str(download_dir / f"input{ext}")

        tg_file = await ctx.bot.get_file(doc.file_id)
        await tg_file.download_to_drive(file_path)
    except Exception as e:
        log.error("convert.download_failed", error=str(e))
        await progress_msg.edit_text("❌ Failed to download file. Please try again.")
        return

    await progress_msg.edit_text("📦 File received! Creating job…")

    # Create DB job with user settings
    try:
        async with AsyncSessionLocal() as db:
            job = Job(
                id=uuid.UUID(job_id),
                user_telegram_id=tg_user.id,
                original_filename=doc.file_name,
                file_path=file_path,
                file_size_bytes=doc.file_size,
                quality=user.settings.get("quality", settings.default_quality),
                voice_mode=user.settings.get("voice_mode", "female"),
                tts_engine=user.settings.get("tts_engine", settings.tts_engine),
                language=user.settings.get("language", "hi"),
                status=JobStatus.PENDING,
            )
            db.add(job)
            user.total_jobs += 1
            await db.commit()
    except Exception as e:
        log.error("convert.db_create_failed", error=str(e))
        await progress_msg.edit_text(
            "❌ Failed to create job in database.\n"
            "Please ensure the database is running and migrations are applied."
        )
        return

    # Enqueue Celery task
    try:
        from app.workers.tasks import process_manga
        task = process_manga.apply_async(args=[job_id], queue="pipeline")

        # Update job with Celery task ID
        async with AsyncSessionLocal() as db:
            stmt = select(Job).where(Job.id == uuid.UUID(job_id))
            result = await db.execute(stmt)
            j = result.scalar_one_or_none()
            if j:
                j.celery_task_id = task.id
                await db.commit()

        await progress_msg.edit_text(
            f"✅ *Job queued!*\n\n"
            f"📄 File: `{doc.file_name}`\n"
            f"🆔 Job ID: `{job_id[:8]}…`\n"
            f"🎯 Quality: {user.settings.get('quality', '720p')}\n"
            f"🗣 Voice: {user.settings.get('voice_mode', 'female')}\n\n"
            f"Use /status to track progress.\n"
            f"I'll notify you when the video is ready! 🎬",
            parse_mode="Markdown",
        )
        log.info("convert.queued", job_id=job_id, user=tg_user.id, task_id=task.id)

    except Exception as e:
        log.error("convert.queue_failed", error=str(e))
        # Job is saved in DB even if Celery is unavailable
        await progress_msg.edit_text(
            f"⚠️ *File received but worker is unavailable!*\n\n"
            f"📄 File: `{doc.file_name}`\n"
            f"🆔 Job ID: `{job_id[:8]}…`\n\n"
            f"The job has been saved. Please ensure the Celery worker is running.\n"
            f"Use /status to check when processing starts.",
            parse_mode="Markdown",
        )
