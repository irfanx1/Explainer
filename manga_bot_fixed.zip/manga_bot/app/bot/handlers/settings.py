"""User settings handler."""
from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from app.core.database import AsyncSessionLocal
from app.core.logging import get_logger
from app.models.user import User
from sqlalchemy import select

log = get_logger(__name__)


def _settings_keyboard(current: dict) -> InlineKeyboardMarkup:
    q = current.get("quality", "720p")
    v = current.get("voice_mode", "female")
    t = current.get("tts_engine", "gtts")

    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(f"{'✅' if q == '480p' else '⬜'} 480p",  callback_data="settings:quality:480p"),
            InlineKeyboardButton(f"{'✅' if q == '720p' else '⬜'} 720p",  callback_data="settings:quality:720p"),
            InlineKeyboardButton(f"{'✅' if q == '1080p' else '⬜'} 1080p", callback_data="settings:quality:1080p"),
        ],
        [
            InlineKeyboardButton(f"{'✅' if v == 'female' else '⬜'} Female Voice",   callback_data="settings:voice:female"),
            InlineKeyboardButton(f"{'✅' if v == 'male' else '⬜'} Male Voice",       callback_data="settings:voice:male"),
            InlineKeyboardButton(f"{'✅' if v == 'narrator' else '⬜'} Narrator",    callback_data="settings:voice:narrator"),
        ],
        [
            InlineKeyboardButton(f"{'✅' if t == 'gtts' else '⬜'} gTTS (Free)",        callback_data="settings:tts:gtts"),
            InlineKeyboardButton(f"{'✅' if t == 'elevenlabs' else '⬜'} ElevenLabs",  callback_data="settings:tts:elevenlabs"),
            InlineKeyboardButton(f"{'✅' if t == 'coqui' else '⬜'} Coqui (GPU)",     callback_data="settings:tts:coqui"),
        ],
        [InlineKeyboardButton("💾 Done", callback_data="settings:done")],
    ])


async def handle_settings_command(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    async with AsyncSessionLocal() as db:
        stmt = select(User).where(User.telegram_id == uid)
        result = await db.execute(stmt)
        user = result.scalar_one_or_none()
        s = user.settings if user else {}

    await update.message.reply_text(
        "⚙️ *Settings*\n\nChoose your preferences:",
        parse_mode="Markdown",
        reply_markup=_settings_keyboard(s),
    )


async def handle_settings_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    uid = update.effective_user.id
    parts = query.data.split(":")

    if parts[1] == "done":
        await query.edit_message_text("✅ Settings saved!")
        return

    async with AsyncSessionLocal() as db:
        stmt = select(User).where(User.telegram_id == uid)
        result = await db.execute(stmt)
        user = result.scalar_one_or_none()
        if not user:
            await query.edit_message_text("❌ User not found.")
            return

        category, value = parts[1], parts[2]
        if category == "quality":
            user.settings = {**user.settings, "quality": value}
        elif category == "voice":
            user.settings = {**user.settings, "voice_mode": value}
        elif category == "tts":
            user.settings = {**user.settings, "tts_engine": value}

        await db.commit()
        await db.refresh(user)
        s = user.settings

    await query.edit_message_reply_markup(reply_markup=_settings_keyboard(s))
