"""Job status handler."""
from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from app.core.database import AsyncSessionLocal
from app.core.redis_client import get_job_progress
from app.models.job import Job, JobStatus
from sqlalchemy import select, desc

STATUS_EMOJI = {
    JobStatus.PENDING:    "⏳",
    JobStatus.EXTRACTING: "📂",
    JobStatus.OCR:        "🔍",
    JobStatus.AI_ANALYZE: "🤖",
    JobStatus.TTS:        "🗣",
    JobStatus.RENDERING:  "🎬",
    JobStatus.UPLOADING:  "☁️",
    JobStatus.DONE:       "✅",
    JobStatus.FAILED:     "❌",
    JobStatus.CANCELLED:  "🚫",
    JobStatus.PAUSED:     "⏸",
}

PROGRESS_BAR_LEN = 10


def _bar(pct: float) -> str:
    filled = int(pct / 100 * PROGRESS_BAR_LEN)
    return "█" * filled + "░" * (PROGRESS_BAR_LEN - filled)


async def handle_status_command(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    async with AsyncSessionLocal() as db:
        stmt = (
            select(Job)
            .where(Job.user_telegram_id == uid)
            .where(Job.status.not_in([JobStatus.DONE, JobStatus.FAILED]))
            .order_by(desc(Job.created_at))
            .limit(5)
        )
        result = await db.execute(stmt)
        active_jobs = result.scalars().all()

    if not active_jobs:
        await update.message.reply_text(
            "No active jobs.\nSend a manga file or use /convert!"
        )
        return

    lines = ["📊 *Active Jobs*\n"]
    for job in active_jobs:
        emoji = STATUS_EMOJI.get(job.status, "❓")
        # Check Redis for live progress
        live = await get_job_progress(str(job.id))
        pct = live["pct"] if live else job.progress_pct
        step = live["step"] if live else (job.current_step or "")

        lines.append(
            f"{emoji} `{str(job.id)[:8]}…` — {job.status.value}\n"
            f"   [{_bar(pct)}] {pct:.0f}%\n"
            f"   📄 {job.original_filename or 'unknown'}\n"
            f"   💬 {step}\n"
        )

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
