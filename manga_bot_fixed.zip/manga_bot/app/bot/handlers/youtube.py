"""YouTube upload handler."""
from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from app.core.config import settings
from app.core.database import AsyncSessionLocal
from app.models.job import Job, JobStatus
from sqlalchemy import select, desc


async def handle_youtube_command(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not settings.youtube_upload_enabled:
        await update.message.reply_text(
            "❌ YouTube upload is not configured.\n"
            "Set `YOUTUBE_UPLOAD_ENABLED=true` and configure OAuth credentials."
        )
        return

    uid = update.effective_user.id
    async with AsyncSessionLocal() as db:
        stmt = (
            select(Job)
            .where(Job.user_telegram_id == uid, Job.status == JobStatus.DONE)
            .order_by(desc(Job.finished_at))
            .limit(1)
        )
        result = await db.execute(stmt)
        job = result.scalar_one_or_none()

    if not job:
        await update.message.reply_text("No completed videos yet. Convert a manga first!")
        return

    if job.youtube_url:
        await update.message.reply_text(f"Already uploaded: {job.youtube_url}")
        return

    await update.message.reply_text("🎬 Uploading to YouTube… This may take a few minutes.")

    from app.workers.tasks import upload_youtube
    upload_youtube.apply_async(args=[str(job.id)], queue="upload")
