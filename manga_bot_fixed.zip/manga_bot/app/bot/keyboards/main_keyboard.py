"""Reusable Telegram keyboard builders."""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup


def quality_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📱 480p", callback_data="quality:480p"),
            InlineKeyboardButton("🖥 720p", callback_data="quality:720p"),
            InlineKeyboardButton("🎬 1080p", callback_data="quality:1080p"),
        ]
    ])


def main_menu_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        [
            ["🎌 Convert Manga", "⚙️ Settings"],
            ["📊 Status", "📜 History"],
            ["🎬 YouTube", "❓ Help"],
        ],
        resize_keyboard=True,
    )
