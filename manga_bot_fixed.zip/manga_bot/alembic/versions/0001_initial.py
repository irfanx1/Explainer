"""Initial schema

Revision ID: 0001_initial
Revises:
Create Date: 2025-01-01 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── users ──────────────────────────────────────────────────────────────
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("telegram_id", sa.BigInteger(), nullable=False, unique=True, index=True),
        sa.Column("username", sa.String(64)),
        sa.Column("full_name", sa.String(128)),
        sa.Column("language_code", sa.String(8), default="en"),
        sa.Column("settings", postgresql.JSONB(), nullable=False, default={}),
        sa.Column("is_admin", sa.Boolean(), default=False),
        sa.Column("is_banned", sa.Boolean(), default=False),
        sa.Column("total_jobs", sa.Integer(), default=0),
        sa.Column("total_videos", sa.Integer(), default=0),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("last_seen_at", sa.DateTime(timezone=True)),
    )

    # ── jobs ───────────────────────────────────────────────────────────────
    job_status = postgresql.ENUM(
        "pending", "extracting", "ocr", "ai_analyze", "tts",
        "rendering", "uploading", "done", "failed", "cancelled", "paused",
        name="jobstatus",
    )
    job_status.create(op.get_bind())

    op.create_table(
        "jobs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_telegram_id", sa.BigInteger(), nullable=False, index=True),
        sa.Column("celery_task_id", sa.String(128)),
        sa.Column("original_filename", sa.String(256)),
        sa.Column("file_path", sa.Text()),
        sa.Column("file_size_bytes", sa.Integer()),
        sa.Column("total_pages", sa.Integer()),
        sa.Column("quality", sa.String(16), default="720p"),
        sa.Column("voice_mode", sa.String(32), default="female"),
        sa.Column("tts_engine", sa.String(32), default="gtts"),
        sa.Column("language", sa.String(8), default="hi"),
        sa.Column("status", job_status, nullable=False, default="pending", index=True),
        sa.Column("progress_pct", sa.Float(), default=0.0),
        sa.Column("current_step", sa.String(128)),
        sa.Column("error_message", sa.Text()),
        sa.Column("retry_count", sa.Integer(), default=0),
        sa.Column("output_path", sa.Text()),
        sa.Column("output_url", sa.Text()),
        sa.Column("video_duration_seconds", sa.Float()),
        sa.Column("youtube_url", sa.Text()),
        sa.Column("artifacts", postgresql.JSONB(), default={}),
        sa.Column("ai_analysis", postgresql.JSONB(), default={}),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("started_at", sa.DateTime(timezone=True)),
        sa.Column("finished_at", sa.DateTime(timezone=True)),
    )

    # ── characters ─────────────────────────────────────────────────────────
    op.create_table(
        "characters",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_telegram_id", sa.BigInteger(), nullable=False, index=True),
        sa.Column("series_name", sa.String(256), nullable=False, index=True),
        sa.Column("character_name", sa.String(128), nullable=False),
        sa.Column("aliases", postgresql.JSONB(), default=[]),
        sa.Column("description", sa.Text(), default=""),
        sa.Column("personality_traits", postgresql.JSONB(), default=[]),
        sa.Column("appearance", postgresql.JSONB(), default={}),
        sa.Column("relationships", postgresql.JSONB(), default={}),
        sa.Column("first_seen_page", sa.Integer(), default=0),
        sa.Column("embedding", postgresql.JSONB(), default=[]),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # ── plugins ────────────────────────────────────────────────────────────
    op.create_table(
        "plugins",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(128), nullable=False, unique=True),
        sa.Column("version", sa.String(32), nullable=False),
        sa.Column("description", sa.Text(), default=""),
        sa.Column("module_path", sa.Text(), nullable=False),
        sa.Column("hook_type", sa.String(64), nullable=False),
        sa.Column("is_enabled", sa.Boolean(), default=True),
        sa.Column("config", postgresql.JSONB(), default={}),
        sa.Column("installed_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("plugins")
    op.drop_table("characters")
    op.drop_table("jobs")
    op.drop_table("users")
    op.execute("DROP TYPE IF EXISTS jobstatus")
