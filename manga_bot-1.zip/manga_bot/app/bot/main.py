"""
Telegram Bot — main entry point.
Registers all handlers and starts polling / webhook.
Also runs Redis subscriber to send results back to users.
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

import redis.asyncio as aioredis
from telegram import Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from app.bot.handlers.convert import handle_convert_command, handle_document_upload
from app.bot.handlers.settings import handle_settings_command, handle_settings_callback
from app.bot.handlers.status import handle_status_command
from app.bot.handlers.history import handle_history_command
from app.bot.handlers.youtube import handle_youtube_command
from app.bot.handlers.admin import handle_admin_command
from app.core.config import settings
from app.core.database import init_db
from app.core.logging import get_logger, setup_logging

setup_logging()
log = get_logger(__name__)


async def handle_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "🎌 *Manga to Video Bot*\n\n"
        "Send me any manga file (PDF, CBZ, ZIP) and I'll convert it into an "
        "animated Hindi explanation video!\n\n"
        "Commands:\n"
        "/convert — Upload & convert manga\n"
        "/settings — Change quality, voice, language\n"
        "/status — Check conversion progress\n"
        "/history — Your past conversions\n"
        "/youtube — Upload last video to YouTube\n",
        parse_mode="Markdown",
    )


async def handle_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "📖 *Help*\n\n"
        "1️⃣ Use /convert or just send a manga file\n"
        "2️⃣ Supported formats: PDF, CBZ, ZIP, RAR, 7z\n"
        "3️⃣ Max size: 100 MB\n"
        "4️⃣ Track progress with /status\n"
        "5️⃣ Change voice/quality with /settings\n\n"
        "🌐 Stack: OpenAI GPT-4o + gTTS + FFmpeg + OpenCV",
        parse_mode="Markdown",
    )


async def _redis_subscriber(app: Application) -> None:
    """Listen for Celery task completion events and notify users."""
    r = aioredis.from_url(settings.redis_url, decode_responses=True)
    pubsub = r.pubsub()
    await pubsub.subscribe("job_done", "job_failed", "youtube_done")
    log.info("bot.redis_subscriber.started")

    async for msg in pubsub.listen():
        if msg["type"] != "message":
            continue
        try:
            data = json.loads(msg["data"])
            channel = msg["channel"]
            uid = data.get("user_telegram_id")
            if not uid:
                continue

            if channel == "job_done":
                video_path = data.get("output_path", "")
                title = data.get("series_title", "Manga")
                dur = int(data.get("duration", 0))
                caption = (
                    f"✅ *{title}* — Done!\n"
                    f"⏱ Duration: {dur // 60}m {dur % 60}s\n"
                    f"🎬 Your video is ready!"
                )
                if video_path and os.path.exists(video_path):
                    with open(video_path, "rb") as vf:
                        await app.bot.send_video(
                            chat_id=uid,
                            video=vf,
                            caption=caption,
                            parse_mode="Markdown",
                            supports_streaming=True,
                        )
                else:
                    await app.bot.send_message(chat_id=uid, text=caption, parse_mode="Markdown")

            elif channel == "job_failed":
                error = data.get("error", "Unknown error")
                await app.bot.send_message(
                    chat_id=uid,
                    text=f"❌ Conversion failed:\n`{error[:200]}`\n\nTry /convert again.",
                    parse_mode="Markdown",
                )

            elif channel == "youtube_done":
                url = data.get("url", "")
                await app.bot.send_message(
                    chat_id=uid,
                    text=f"🎬 Uploaded to YouTube!\n{url}",
                )

        except Exception as e:
            log.error("bot.subscriber_error", error=str(e))


async def post_init(app: Application) -> None:
    await init_db()
    asyncio.create_task(_redis_subscriber(app))
    log.info("bot.initialized")


def create_app() -> Application:
    app = (
        Application.builder()
        .token(settings.telegram_bot_token)
        .post_init(post_init)
        .build()
    )

    # Commands
    app.add_handler(CommandHandler("start", handle_start))
    app.add_handler(CommandHandler("help", handle_help))
    app.add_handler(CommandHandler("convert", handle_convert_command))
    app.add_handler(CommandHandler("settings", handle_settings_command))
    app.add_handler(CommandHandler("status", handle_status_command))
    app.add_handler(CommandHandler("history", handle_history_command))
    app.add_handler(CommandHandler("youtube", handle_youtube_command))
    app.add_handler(CommandHandler("admin", handle_admin_command))

    # Document upload (manga files)
    app.add_handler(MessageHandler(
        filters.Document.ALL & ~filters.COMMAND,
        handle_document_upload,
    ))

    # Inline keyboard callbacks
    app.add_handler(CallbackQueryHandler(handle_settings_callback, pattern="^settings:"))

    log.info("bot.handlers_registered")
    return app


def main() -> None:
    app = create_app()
    log.info("bot.polling_start")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
