#!/bin/bash
# ============================================================
#  MangaBot — One-command deploy
#  Usage: bash scripts/deploy.sh
# ============================================================
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# Check .env exists
if [ ! -f ".env" ]; then
    warn ".env not found — copying from .env.example"
    cp .env.example .env
    error "Please fill in .env before deploying (especially TELEGRAM_BOT_TOKEN and OPENAI_API_KEY)"
fi

# Validate required variables
source .env
[ -z "$TELEGRAM_BOT_TOKEN" ] && error "TELEGRAM_BOT_TOKEN is not set in .env"
[ -z "$OPENAI_API_KEY" ]     && error "OPENAI_API_KEY is not set in .env"

info "Building Docker images…"
docker compose build --parallel

info "Starting infrastructure (postgres + redis)…"
docker compose up -d postgres redis
sleep 5

info "Running database migrations…"
docker compose run --rm migrate

info "Starting all services…"
docker compose up -d

info "Waiting for health checks…"
sleep 10

# Check API health
if curl -sf http://localhost:8000/api/v1/health > /dev/null; then
    info "✅ API is healthy"
else
    warn "API health check failed — check logs: docker compose logs api"
fi

echo ""
echo -e "${GREEN}╔══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  MangaBot is running!                ║${NC}"
echo -e "${GREEN}║                                      ║${NC}"
echo -e "${GREEN}║  API:     http://localhost:8000      ║${NC}"
echo -e "${GREEN}║  Flower:  http://localhost:5555      ║${NC}"
echo -e "${GREEN}║  Docs:    http://localhost:8000/docs ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════╝${NC}"
echo ""
info "View logs: docker compose logs -f bot worker"
