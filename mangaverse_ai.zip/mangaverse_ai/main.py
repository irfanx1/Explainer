"""
MangaVerse AI - entrypoint.
Run with: python main.py
"""
import asyncio

from bot.client import app
from config import settings
from core.database import init_db
from core.logger import get_logger, setup_logging

setup_logging()
logger = get_logger(__name__)


async def _startup() -> None:
    settings.validate()
    await init_db()
    logger.info("Database initialized")


def main() -> None:
    asyncio.get_event_loop().run_until_complete(_startup())
    logger.info("Starting MangaVerse AI bot...")
    app.run()


if __name__ == "__main__":
    main()
