"""Centralized logging configuration."""
import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

from config import settings

_LOG_DIR = settings.data_dir / "logs"
_LOG_DIR.mkdir(parents=True, exist_ok=True)
_LOG_FILE = _LOG_DIR / "mangaverse.log"

_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"


def setup_logging() -> None:
    root = logging.getLogger()
    root.setLevel(settings.log_level.upper())

    if root.handlers:
        return  # already configured

    formatter = logging.Formatter(_FORMAT, datefmt="%Y-%m-%d %H:%M:%S")

    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    root.addHandler(console)

    file_handler = RotatingFileHandler(
        _LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)

    # Quiet down noisy third-party loggers
    for noisy in ("pyrogram", "httpx", "asyncio"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def tail_logs(n: int = 50) -> str:
    """Return the last n lines of the log file (used by /logs admin command)."""
    if not _LOG_FILE.exists():
        return "No logs yet."
    with open(_LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()
    return "".join(lines[-n:]) or "No logs yet."
