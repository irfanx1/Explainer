"""
Async database engine/session management + small repository helpers.

Switching from SQLite to PostgreSQL later is just a matter of changing
DATABASE_URL in .env (e.g. postgresql+asyncpg://user:pass@host/db) -
no code changes needed anywhere else in the project.
"""
from __future__ import annotations

import datetime as dt
from contextlib import asynccontextmanager

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from config import settings
from core.models import Base, Job, JobStatus, User

engine = create_async_engine(settings.database_url, echo=False, future=True)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


@asynccontextmanager
async def get_session():
    async with SessionLocal() as session:
        yield session


# ---------------------------------------------------------------- users ----
async def get_or_create_user(telegram_id: int, username: str | None) -> User:
    async with get_session() as session:
        result = await session.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        if user:
            if username and user.username != username:
                user.username = username
                await session.commit()
            return user
        user = User(telegram_id=telegram_id, username=username,
                     is_admin=telegram_id in settings.admin_ids)
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return user


async def set_user_language(telegram_id: int, language: str) -> None:
    async with get_session() as session:
        result = await session.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        if user:
            user.language = language
            await session.commit()


async def set_user_quality(telegram_id: int, quality: str) -> None:
    async with get_session() as session:
        result = await session.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        if user:
            user.video_quality = quality
            await session.commit()


async def set_ban_status(telegram_id: int, banned: bool) -> bool:
    async with get_session() as session:
        result = await session.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        if not user:
            return False
        user.is_banned = banned
        await session.commit()
        return True


async def count_users() -> int:
    async with get_session() as session:
        result = await session.execute(select(func.count(User.id)))
        return result.scalar_one()


async def all_user_telegram_ids() -> list[int]:
    async with get_session() as session:
        result = await session.execute(select(User.telegram_id))
        return [row[0] for row in result.all()]


# ----------------------------------------------------------------- jobs ----
async def create_job(user_id: int, file_name: str, file_path: str) -> Job:
    async with get_session() as session:
        job = Job(user_id=user_id, file_name=file_name, file_path=file_path,
                   status=JobStatus.QUEUED)
        session.add(job)
        await session.commit()
        await session.refresh(job)
        return job


async def update_job_status(job_id: int, status: JobStatus, error: str | None = None) -> None:
    async with get_session() as session:
        result = await session.execute(select(Job).where(Job.id == job_id))
        job = result.scalar_one_or_none()
        if job:
            job.status = status
            job.updated_at = dt.datetime.utcnow()
            if error:
                job.error = error
            await session.commit()


async def set_job_result(job_id: int, result_path: str) -> None:
    async with get_session() as session:
        result = await session.execute(select(Job).where(Job.id == job_id))
        job = result.scalar_one_or_none()
        if job:
            job.result_path = result_path
            job.status = JobStatus.DONE
            await session.commit()


async def set_job_progress_message(job_id: int, message_id: int) -> None:
    async with get_session() as session:
        result = await session.execute(select(Job).where(Job.id == job_id))
        job = result.scalar_one_or_none()
        if job:
            job.progress_message_id = message_id
            await session.commit()


async def get_job(job_id: int) -> Job | None:
    async with get_session() as session:
        result = await session.execute(select(Job).where(Job.id == job_id))
        return result.scalar_one_or_none()


async def user_history(user_id: int, limit: int = 10) -> list[Job]:
    async with get_session() as session:
        result = await session.execute(
            select(Job).where(Job.user_id == user_id).order_by(Job.created_at.desc()).limit(limit)
        )
        return list(result.scalars().all())


async def queue_stats() -> dict:
    async with get_session() as session:
        total = await session.execute(select(func.count(Job.id)))
        active = await session.execute(
            select(func.count(Job.id)).where(
                Job.status.in_([JobStatus.QUEUED, JobStatus.READING, JobStatus.UNDERSTANDING,
                                JobStatus.VOICING, JobStatus.RENDERING, JobStatus.UPLOADING])
            )
        )
        done = await session.execute(select(func.count(Job.id)).where(Job.status == JobStatus.DONE))
        failed = await session.execute(select(func.count(Job.id)).where(Job.status == JobStatus.FAILED))
        return {
            "total": total.scalar_one(),
            "active": active.scalar_one(),
            "done": done.scalar_one(),
            "failed": failed.scalar_one(),
        }
