"""
In-process async queue manager.

Keeps things dependency-free (no Redis needed to run for free), while still
being swappable later: replace this module's internals with an RQ/Celery
backend without touching bot handlers, since they only call submit()/cancel().
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Awaitable, Callable

from config import settings
from core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class QueueItem:
    job_id: int
    coro_factory: Callable[[], Awaitable[None]]
    task: asyncio.Task | None = field(default=None, repr=False)


class QueueManager:
    def __init__(self, max_concurrent: int | None = None):
        self._sem = asyncio.Semaphore(max_concurrent or settings.max_concurrent_jobs)
        self._items: dict[int, QueueItem] = {}
        self._pending_order: list[int] = []
        self._maintenance = settings.maintenance_mode

    @property
    def maintenance_mode(self) -> bool:
        return self._maintenance

    def set_maintenance(self, on: bool) -> None:
        self._maintenance = on

    def position_of(self, job_id: int) -> int:
        """1-based position in the pending queue, 0 if already running/done."""
        try:
            return self._pending_order.index(job_id) + 1
        except ValueError:
            return 0

    def active_count(self) -> int:
        return sum(1 for i in self._items.values() if i.task and not i.task.done())

    def pending_count(self) -> int:
        return len(self._pending_order)

    async def submit(self, job_id: int, coro_factory: Callable[[], Awaitable[None]]) -> None:
        item = QueueItem(job_id=job_id, coro_factory=coro_factory)
        self._items[job_id] = item
        self._pending_order.append(job_id)
        item.task = asyncio.create_task(self._run(item))

    async def _run(self, item: QueueItem) -> None:
        async with self._sem:
            if item.job_id in self._pending_order:
                self._pending_order.remove(item.job_id)
            try:
                await asyncio.wait_for(item.coro_factory(), timeout=settings.job_timeout_seconds)
            except asyncio.CancelledError:
                logger.info("Job %s cancelled", item.job_id)
            except asyncio.TimeoutError:
                logger.error("Job %s timed out", item.job_id)
            except Exception:
                logger.exception("Job %s failed with an unhandled exception", item.job_id)

    def cancel(self, job_id: int) -> bool:
        item = self._items.get(job_id)
        if item and item.task and not item.task.done():
            item.task.cancel()
            if job_id in self._pending_order:
                self._pending_order.remove(job_id)
            return True
        return False


queue_manager = QueueManager()
