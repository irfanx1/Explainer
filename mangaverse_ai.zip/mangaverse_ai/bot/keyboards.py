"""Reusable inline keyboard builders for a clean, consistent UI."""
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def main_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("⚙️ Settings", callback_data="menu:settings"),
             InlineKeyboardButton("📜 History", callback_data="menu:history")],
            [InlineKeyboardButton("❓ Help", callback_data="menu:help"),
             InlineKeyboardButton("ℹ️ About", callback_data="menu:about")],
        ]
    )


def settings_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("🌐 Language", callback_data="settings:language")],
            [InlineKeyboardButton("🎞️ Video Quality", callback_data="settings:quality")],
            [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
        ]
    )


def language_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("🇬🇧 English", callback_data="lang:en"),
             InlineKeyboardButton("🇯🇵 日本語", callback_data="lang:ja")],
            [InlineKeyboardButton("⬅️ Back", callback_data="menu:settings")],
        ]
    )


def quality_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("480p", callback_data="quality:480p"),
             InlineKeyboardButton("720p", callback_data="quality:720p"),
             InlineKeyboardButton("1080p", callback_data="quality:1080p")],
            [InlineKeyboardButton("⬅️ Back", callback_data="menu:settings")],
        ]
    )


def cancel_keyboard(job_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("🚫 Cancel Processing", callback_data=f"cancel:{job_id}")]]
    )


def retry_keyboard(job_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("🔁 Retry", callback_data=f"retry:{job_id}")]]
    )
