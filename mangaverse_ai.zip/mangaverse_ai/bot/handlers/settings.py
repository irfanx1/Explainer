"""Handles /settings command plus language & quality callback selections."""
from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, Message

from bot.keyboards import settings_keyboard
from core.database import set_user_language, set_user_quality


@Client.on_message(filters.command("settings"))
async def settings_command(client: Client, message: Message):
    await message.reply_text("⚙️ **Settings**\n\nChoose what you'd like to change:",
                              reply_markup=settings_keyboard())


@Client.on_callback_query(filters.regex(r"^lang:"))
async def language_selected(client: Client, query: CallbackQuery):
    lang = query.data.split(":", 1)[1]
    await set_user_language(query.from_user.id, lang)
    label = "English 🇬🇧" if lang == "en" else "日本語 🇯🇵"
    await query.answer(f"Narration language set to {label}", show_alert=False)
    await query.message.edit_text("⚙️ **Settings**\n\nChoose what you'd like to change:",
                                   reply_markup=settings_keyboard())


@Client.on_callback_query(filters.regex(r"^quality:"))
async def quality_selected(client: Client, query: CallbackQuery):
    quality = query.data.split(":", 1)[1]
    await set_user_quality(query.from_user.id, quality)
    await query.answer(f"Video quality set to {quality}", show_alert=False)
    await query.message.edit_text("⚙️ **Settings**\n\nChoose what you'd like to change:",
                                   reply_markup=settings_keyboard())
