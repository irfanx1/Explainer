"""
Core workflow handler:
1. User sends a manga file -> we validate & store it.
2. User replies "/manga" (to that file, or just sends the command) -> we
   queue a job and process it through the full pipeline, editing a single
   progress message live as it moves through each stage.
"""
from __future__ import annotations

from pathlib import Path

from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, Message

from bot.keyboards import cancel_keyboard, retry_keyboard
from config import settings
from core.database import (
    create_job,
    get_job,
    get_or_create_user,
    set_job_progress_message,
    set_job_result,
    update_job_status,
)
from core.logger import get_logger
from core.models import JobStatus
from core.queue_manager import queue_manager
from processing.pipeline import run_pipeline
from utils.helpers import build_progress_text, safe_edit
from utils.validators import validate_upload

logger = get_logger(__name__)

# Tracks the most recently uploaded (but not-yet-processed) file per user.
# Keyed by telegram user id -> local file path.
_pending_uploads: dict[int, Path] = {}


@Client.on_message(filters.document | (filters.photo & filters.private))
async def receive_manga_file(client: Client, message: Message):
    user = await get_or_create_user(message.from_user.id, message.from_user.username)
    if user.is_banned:
        return

    if message.document:
        file_name = message.document.file_name or "upload"
        file_size = message.document.file_size or 0
    else:
        file_name = f"photo_{message.photo.file_unique_id}.jpg"
        file_size = message.photo.file_size or 0

    ok, error = validate_upload(file_name, file_size)
    if not ok:
        await message.reply_text(f"⚠️ {error}")
        return

    dest_dir = settings.temp_dir / "uploads" / str(message.from_user.id)
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_path = dest_dir / file_name

    await message.download(file_name=str(dest_path))
    _pending_uploads[message.from_user.id] = dest_path

    await message.reply_text(
        f"📥 Got **{file_name}**!\n\nReply with /manga (or just send /manga) to start processing.",
    )


@Client.on_message(filters.command("manga"))
async def start_manga_processing(client: Client, message: Message):
    user = await get_or_create_user(message.from_user.id, message.from_user.username)
    if user.is_banned:
        await message.reply_text("🚫 You are banned from using this bot.")
        return
    if queue_manager.maintenance_mode:
        await message.reply_text("🛠️ The bot is currently under maintenance. Please try again shortly.")
        return

    source_path = _resolve_source_file(message)
    if source_path is None:
        await message.reply_text(
            "⚠️ Please send a manga file first, then reply with /manga (or send /manga right after uploading)."
        )
        return

    job = await create_job(user_id=user.id, file_name=source_path.name, file_path=str(source_path))
    progress_msg = await message.reply_text(
        build_progress_text(JobStatus.QUEUED, "Queued for processing...", queue_manager.pending_count() + 1),
        reply_markup=cancel_keyboard(job.id),
    )
    await set_job_progress_message(job.id, progress_msg.id)

    async def on_progress(status: JobStatus, detail: str) -> None:
        await safe_edit(progress_msg, build_progress_text(status, detail), reply_markup=cancel_keyboard(job.id))

    async def job_runner() -> None:
        try:
            output_path = await run_pipeline(
                job_id=job.id,
                source_path=source_path,
                language=user.language,
                quality=user.video_quality,
                on_progress=on_progress,
            )
            await set_job_result(job.id, str(output_path))
            await safe_edit(progress_msg, "🎉 Your manga explainer video is ready!")
            await client.send_video(
                chat_id=message.chat.id,
                video=str(output_path),
                caption=f"🎬 **{source_path.stem}** — narrated explainer video",
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("Job %s failed", job.id)
            await safe_edit(
                progress_msg,
                f"❌ Processing failed:\n`{str(exc)[:300]}`",
                reply_markup=retry_keyboard(job.id),
            )
        finally:
            _pending_uploads.pop(message.from_user.id, None)

    await queue_manager.submit(job.id, job_runner)


@Client.on_callback_query(filters.regex(r"^cancel:"))
async def cancel_job(client: Client, query: CallbackQuery):
    job_id = int(query.data.split(":", 1)[1])
    cancelled = queue_manager.cancel(job_id)
    if cancelled:
        await update_job_status(job_id, JobStatus.CANCELLED)
        await safe_edit(query.message, "🚫 Processing cancelled.")
    await query.answer("Cancelled" if cancelled else "Job already finished or not found")


@Client.on_callback_query(filters.regex(r"^retry:"))
async def retry_job(client: Client, query: CallbackQuery):
    job_id = int(query.data.split(":", 1)[1])
    job = await get_job(job_id)
    if not job:
        await query.answer("Job not found", show_alert=True)
        return

    source_path = Path(job.file_path)
    if not source_path.exists():
        await query.answer("Original file is no longer available, please re-upload.", show_alert=True)
        return

    _pending_uploads[query.from_user.id] = source_path
    await query.answer("Retrying...")
    await query.message.reply_text("🔁 Retrying — reply with /manga to restart processing.")


@Client.on_message(filters.command("cancel"))
async def cancel_command(client: Client, message: Message):
    """Allows cancelling without tapping the inline button, e.g. /cancel <job_id>."""
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.reply_text("Usage: `/cancel <job_id>` (see /history for job IDs)")
        return
    job_id = int(parts[1])
    cancelled = queue_manager.cancel(job_id)
    await message.reply_text("🚫 Cancelled." if cancelled else "That job isn't running anymore.")


def _resolve_source_file(message: Message) -> Path | None:
    """/manga can be used as a reply to the uploaded file, or right after uploading."""
    if message.reply_to_message and message.reply_to_message.document:
        dest_dir = settings.temp_dir / "uploads" / str(message.from_user.id)
        candidate = dest_dir / message.reply_to_message.document.file_name
        if candidate.exists():
            return candidate
    return _pending_uploads.get(message.from_user.id)
