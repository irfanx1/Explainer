"""/start command and main menu navigation."""
from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, Message

from bot.keyboards import (
    language_keyboard,
    main_menu_keyboard,
    quality_keyboard,
    settings_keyboard,
)
from core.database import get_or_create_user

WELCOME_TEXT = (
    "✨ **Welcome to MangaVerse AI** ✨\n\n"
    "Send me a manga file — **PDF, CBZ, ZIP, CBR, or images** — and reply to it "
    "with **/manga** to get a fully narrated, cinematic explainer video:\n\n"
    "📖 Reading → 🧠 Understanding → 🎙️ Voice-over → 🎬 Rendering → ✅ Delivered\n\n"
    "Use the buttons below to customize your experience."
)

HELP_TEXT = (
    "**How it works**\n\n"
    "1️⃣ Send a manga file (PDF / CBZ / ZIP / CBR / images)\n"
    "2️⃣ Reply to that file with `/manga`\n"
    "3️⃣ Sit back — I'll read it, understand the story, and generate a "
    "narrated explainer video\n\n"
    "**Other commands**\n"
    "`/history` — view your past jobs\n"
    "`/cancel` — cancel your current job\n"
    "`/settings` — language & video quality"
)

ABOUT_TEXT = (
    "**MangaVerse AI**\n\n"
    "An AI-powered manga explainer bot. Built with Gemini + free open-source "
    "OCR/TTS tools. Your uploads are processed privately and cleaned up after delivery."
)


@Client.on_message(filters.command("start"))
async def start_command(client: Client, message: Message):
    await get_or_create_user(message.from_user.id, message.from_user.username)
    await message.reply_text(WELCOME_TEXT, reply_markup=main_menu_keyboard())


@Client.on_callback_query(filters.regex(r"^menu:"))
async def menu_router(client: Client, query: CallbackQuery):
    action = query.data.split(":", 1)[1]

    if action == "main":
        await query.message.edit_text(WELCOME_TEXT, reply_markup=main_menu_keyboard())
    elif action == "settings":
        await query.message.edit_text("⚙️ **Settings**\n\nChoose what you'd like to change:",
                                       reply_markup=settings_keyboard())
    elif action == "help":
        await query.message.edit_text(HELP_TEXT, reply_markup=main_menu_keyboard())
    elif action == "about":
        await query.message.edit_text(ABOUT_TEXT, reply_markup=main_menu_keyboard())
    elif action == "history":
        # Delegated to history.py's own callback, but keep a friendly fallback here
        await query.message.edit_text("📜 Loading your history...", reply_markup=main_menu_keyboard())
    await query.answer()


@Client.on_callback_query(filters.regex(r"^settings:"))
async def settings_router(client: Client, query: CallbackQuery):
    action = query.data.split(":", 1)[1]
    if action == "language":
        await query.message.edit_text("🌐 **Choose narration language:**", reply_markup=language_keyboard())
    elif action == "quality":
        await query.message.edit_text("🎞️ **Choose video quality:**", reply_markup=quality_keyboard())
    await query.answer()
