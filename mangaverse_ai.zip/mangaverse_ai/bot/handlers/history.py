"""/history command - shows a user's past jobs with status and retry option."""
from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, Message

from bot.keyboards import retry_keyboard
from core.database import get_or_create_user, user_history

STATUS_LABEL = {
    "done": "✅ Done",
    "failed": "❌ Failed",
    "cancelled": "🚫 Cancelled",
    "queued": "⏳ Queued",
    "reading": "📖 Reading",
    "understanding": "🧠 Understanding",
    "voicing": "🎙️ Voicing",
    "rendering": "🎬 Rendering",
    "uploading": "✅ Uploading",
}


@Client.on_message(filters.command("history"))
async def history_command(client: Client, message: Message):
    user = await get_or_create_user(message.from_user.id, message.from_user.username)
    jobs = await user_history(user.id, limit=10)

    if not jobs:
        await message.reply_text("📜 You haven't processed any manga yet. Send one to get started!")
        return

    lines = ["📜 **Your Processing History**\n"]
    for job in jobs:
        status_label = STATUS_LABEL.get(job.status.value, job.status.value)
        lines.append(f"`#{job.id}` — {job.file_name} — {status_label}")

    text = "\n".join(lines)
    last_failed = next((j for j in jobs if j.status.value == "failed"), None)
    if last_failed:
        await message.reply_text(text, reply_markup=retry_keyboard(last_failed.id))
    else:
        await message.reply_text(text)


@Client.on_callback_query(filters.regex(r"^menu:history$"))
async def history_from_menu(client: Client, query: CallbackQuery):
    user = await get_or_create_user(query.from_user.id, query.from_user.username)
    jobs = await user_history(user.id, limit=10)
    if not jobs:
        await query.message.edit_text("📜 You haven't processed any manga yet. Send one to get started!")
    else:
        lines = ["📜 **Your Processing History**\n"]
        for job in jobs:
            status_label = STATUS_LABEL.get(job.status.value, job.status.value)
            lines.append(f"`#{job.id}` — {job.file_name} — {status_label}")
        await query.message.edit_text("\n".join(lines))
    await query.answer()
