"""
Admin panel. All commands here are gated by config.settings.admin_ids -
non-admins get a polite refusal.
"""
from __future__ import annotations

import asyncio
import os
import sys

from pyrogram import Client, filters
from pyrogram.types import Message

from config import settings
from core.database import all_user_telegram_ids, count_users, queue_stats, set_ban_status
from core.logger import get_logger, tail_logs
from core.queue_manager import queue_manager
from utils.system_stats import get_server_status

logger = get_logger(__name__)


def admin_filter(_, __, message: Message) -> bool:
    return bool(message.from_user and message.from_user.id in settings.admin_ids)


is_admin = filters.create(admin_filter)


@Client.on_message(filters.command("admin"))
async def admin_help(client: Client, message: Message):
    if message.from_user.id not in settings.admin_ids:
        await message.reply_text("🚫 This command is for admins only.")
        return
    await message.reply_text(
        "🛠️ **Admin Panel**\n\n"
        "`/broadcast <text>` — message every user\n"
        "`/stats` — user & job statistics\n"
        "`/queue` — current queue status\n"
        "`/ban <user_id>` / `/unban <user_id>`\n"
        "`/maintenance on|off` — toggle maintenance mode\n"
        "`/logs [n]` — view last n log lines\n"
        "`/server` — CPU / RAM / Disk usage\n"
        "`/restart_worker` — restart the bot process"
    )


@Client.on_message(filters.command("broadcast") & is_admin)
async def broadcast_command(client: Client, message: Message):
    text = message.text.split(" ", 1)
    if len(text) < 2:
        await message.reply_text("Usage: `/broadcast <message>`")
        return
    content = text[1]

    user_ids = await all_user_telegram_ids()
    status_msg = await message.reply_text(f"📣 Broadcasting to {len(user_ids)} users...")

    sent, failed = 0, 0
    for uid in user_ids:
        try:
            await client.send_message(uid, f"📣 **Announcement**\n\n{content}")
            sent += 1
        except Exception:  # noqa: BLE001
            failed += 1
        await asyncio.sleep(0.05)  # gentle rate limiting

    await status_msg.edit_text(f"📣 Broadcast complete.\n✅ Sent: {sent}\n❌ Failed: {failed}")


@Client.on_message(filters.command("stats") & is_admin)
async def stats_command(client: Client, message: Message):
    total_users = await count_users()
    jobs = await queue_stats()
    await message.reply_text(
        "📊 **Bot Statistics**\n\n"
        f"👥 Total users: `{total_users}`\n"
        f"📦 Total jobs: `{jobs['total']}`\n"
        f"⚙️ Active jobs: `{jobs['active']}`\n"
        f"✅ Completed: `{jobs['done']}`\n"
        f"❌ Failed: `{jobs['failed']}`"
    )


@Client.on_message(filters.command("queue") & is_admin)
async def queue_command(client: Client, message: Message):
    await message.reply_text(
        "🗂️ **Queue Status**\n\n"
        f"🏃 Running: `{queue_manager.active_count()}`\n"
        f"⏳ Pending: `{queue_manager.pending_count()}`\n"
        f"🛠️ Maintenance mode: `{queue_manager.maintenance_mode}`"
    )


@Client.on_message(filters.command("ban") & is_admin)
async def ban_command(client: Client, message: Message):
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.reply_text("Usage: `/ban <telegram_user_id>`")
        return
    ok = await set_ban_status(int(parts[1]), True)
    await message.reply_text("🚫 User banned." if ok else "User not found.")


@Client.on_message(filters.command("unban") & is_admin)
async def unban_command(client: Client, message: Message):
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.reply_text("Usage: `/unban <telegram_user_id>`")
        return
    ok = await set_ban_status(int(parts[1]), False)
    await message.reply_text("✅ User unbanned." if ok else "User not found.")


@Client.on_message(filters.command("maintenance") & is_admin)
async def maintenance_command(client: Client, message: Message):
    parts = message.text.split()
    if len(parts) < 2 or parts[1].lower() not in ("on", "off"):
        await message.reply_text("Usage: `/maintenance on|off`")
        return
    on = parts[1].lower() == "on"
    queue_manager.set_maintenance(on)
    await message.reply_text(f"🛠️ Maintenance mode {'enabled' if on else 'disabled'}.")


@Client.on_message(filters.command("logs") & is_admin)
async def logs_command(client: Client, message: Message):
    parts = message.text.split()
    n = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 50
    logs = tail_logs(n)
    if len(logs) > 3500:
        logs = logs[-3500:]
    await message.reply_text(f"📄 **Last {n} log lines**\n\n```\n{logs}\n```")


@Client.on_message(filters.command("server") & is_admin)
async def server_command(client: Client, message: Message):
    await message.reply_text(get_server_status())


@Client.on_message(filters.command("restart_worker") & is_admin)
async def restart_worker_command(client: Client, message: Message):
    await message.reply_text("♻️ Restarting worker process...")
    logger.warning("Admin %s triggered a worker restart", message.from_user.id)
    os.execv(sys.executable, [sys.executable] + sys.argv)
