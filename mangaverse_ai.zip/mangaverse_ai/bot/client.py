"""Pyrogram Client instance, shared across all handler modules."""
from pyrogram import Client

from config import settings

app = Client(
    "mangaverse_bot",
    api_id=settings.api_id,
    api_hash=settings.api_hash,
    bot_token=settings.bot_token,
    plugins=dict(root="bot/handlers"),
)
