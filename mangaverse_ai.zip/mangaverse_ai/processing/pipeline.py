"""
Orchestrates the full manga -> explainer video pipeline, reporting progress
through a callback so the Telegram handler can update the user's message
live (📖 Reading -> 🧠 Understanding -> 🎙️ Voicing -> 🎬 Rendering -> ✅ Uploading).
"""
from __future__ import annotations

import shutil
from pathlib import Path
from typing import Awaitable, Callable

from config import settings
from core.database import update_job_status
from core.logger import get_logger
from core.models import JobStatus
from processing.file_extractor import extract_pages
from processing.ocr_engine import ocr_pages
from processing.story_analyzer import generate_narration_script
from processing.translator import translate_text
from processing.tts_engine import get_tts_engine
from processing.video_renderer import render_video

logger = get_logger(__name__)

ProgressCallback = Callable[[JobStatus, str], Awaitable[None]]


async def run_pipeline(
    job_id: int,
    source_path: Path,
    language: str,
    quality: str,
    on_progress: ProgressCallback,
) -> Path:
    """Runs the full pipeline for a single job and returns the output video path."""
    workdir = settings.temp_dir / f"job_{job_id}"
    workdir.mkdir(parents=True, exist_ok=True)

    try:
        # 1. Reading -----------------------------------------------------
        await update_job_status(job_id, JobStatus.READING)
        await on_progress(JobStatus.READING, "📖 Reading manga pages...")
        pages = extract_pages(source_path, workdir)

        raw_text = ocr_pages(pages)
        translated_text = translate_text(raw_text, target_language=language)

        # 2. Understanding -------------------------------------------------
        await update_job_status(job_id, JobStatus.UNDERSTANDING)
        await on_progress(JobStatus.UNDERSTANDING, "🧠 Understanding the story...")
        narration_script = await generate_narration_script(translated_text, language=language)

        # 3. Voicing ---------------------------------------------------
        await update_job_status(job_id, JobStatus.VOICING)
        await on_progress(JobStatus.VOICING, "🎙️ Generating voice-over...")
        audio_path = workdir / "narration.mp3"
        tts = get_tts_engine()
        await tts.synthesize(narration_script, audio_path, language=language)

        # 4. Rendering ---------------------------------------------------
        await update_job_status(job_id, JobStatus.RENDERING)
        await on_progress(JobStatus.RENDERING, "🎬 Rendering final video...")
        output_path = workdir / "output.mp4"
        render_video(pages, audio_path, output_path, quality=quality)

        # 5. Uploading -----------------------------------------------------
        await update_job_status(job_id, JobStatus.UPLOADING)
        await on_progress(JobStatus.UPLOADING, "✅ Uploading result...")

        return output_path

    except Exception as exc:
        logger.exception("Pipeline failed for job %s", job_id)
        await update_job_status(job_id, JobStatus.FAILED, error=str(exc))
        raise
    finally:
        # Clean up intermediate files but keep the final video until it's sent
        pages_dir = workdir / "pages"
        if pages_dir.exists():
            shutil.rmtree(pages_dir, ignore_errors=True)
