"""
Free translation layer (no API key) using deep-translator's Google Translate
backend. Only translates when the detected source language differs from the
target - avoids unnecessary calls and preserves quality for already-English text.
"""
from __future__ import annotations

import re

from deep_translator import GoogleTranslator

from core.logger import get_logger

logger = get_logger(__name__)

_JAPANESE_RE = re.compile(r"[\u3040-\u30ff\u4e00-\u9fff]")

# Matches simple "Name:" style prefixes so we can protect them from translation
_NAME_PREFIX_RE = re.compile(r"^([A-Z][a-zA-Z'\-]{1,20}):\s*")


def needs_translation(text: str, target_language: str) -> bool:
    is_japanese = bool(_JAPANESE_RE.search(text))
    if target_language == "ja":
        return not is_japanese
    return is_japanese


def translate_text(text: str, target_language: str = "en") -> str:
    """Translates text chunk by chunk (to respect API limits), preserving
    'Name:' style prefixes untranslated so character names stay intact."""
    if not text.strip():
        return text
    if not needs_translation(text, target_language):
        return text

    translator = GoogleTranslator(source="auto", target=target_language)
    lines = text.split("\n")
    translated_lines = []

    for line in lines:
        if not line.strip():
            translated_lines.append(line)
            continue

        prefix_match = _NAME_PREFIX_RE.match(line)
        prefix, body = "", line
        if prefix_match:
            prefix, body = prefix_match.group(0), line[prefix_match.end():]

        try:
            translated = translator.translate(body) if body.strip() else body
        except Exception as exc:  # noqa: BLE001
            logger.warning("Translation failed for a line, keeping original: %s", exc)
            translated = body

        translated_lines.append(f"{prefix}{translated}")

    return "\n".join(translated_lines)
