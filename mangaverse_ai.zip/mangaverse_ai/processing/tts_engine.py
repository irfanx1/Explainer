"""
Free, human-like text-to-speech using Microsoft Edge's neural voices via
the open-source `edge-tts` library (no API key, no cost).

Kept behind a small interface (TTSEngine) so the underlying engine can be
swapped later (e.g. for Coqui TTS, Piper, or a paid provider) without
touching the rest of the pipeline.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

import edge_tts

from config import settings
from core.logger import get_logger

logger = get_logger(__name__)


class TTSEngine(ABC):
    @abstractmethod
    async def synthesize(self, text: str, output_path: Path, language: str = "en") -> Path:
        raise NotImplementedError


class EdgeTTSEngine(TTSEngine):
    """Default free engine. Splits long scripts into chunks to avoid
    request-size issues and concatenates the resulting audio."""

    _MAX_CHARS = 3000

    async def synthesize(self, text: str, output_path: Path, language: str = "en") -> Path:
        voice = settings.tts_voice_ja if language == "ja" else settings.tts_voice_en
        chunks = self._chunk_text(text, self._MAX_CHARS)

        if len(chunks) == 1:
            await self._synthesize_chunk(chunks[0], voice, output_path)
            return output_path

        part_paths = []
        for i, chunk in enumerate(chunks):
            part_path = output_path.with_suffix(f".part{i}.mp3")
            await self._synthesize_chunk(chunk, voice, part_path)
            part_paths.append(part_path)

        self._concatenate_audio(part_paths, output_path)
        for p in part_paths:
            p.unlink(missing_ok=True)
        return output_path

    @staticmethod
    async def _synthesize_chunk(text: str, voice: str, output_path: Path) -> None:
        communicate = edge_tts.Communicate(text, voice)
        await communicate.save(str(output_path))

    @staticmethod
    def _chunk_text(text: str, max_chars: int) -> list[str]:
        sentences = text.replace("\n", " ").split(". ")
        chunks, current = [], ""
        for sentence in sentences:
            candidate = f"{current}. {sentence}" if current else sentence
            if len(candidate) > max_chars:
                if current:
                    chunks.append(current.strip() + ".")
                current = sentence
            else:
                current = candidate
        if current:
            chunks.append(current.strip())
        return chunks or [text]

    @staticmethod
    def _concatenate_audio(parts: list[Path], output_path: Path) -> None:
        import ffmpeg

        concat_list = output_path.with_suffix(".txt")
        concat_list.write_text("\n".join(f"file '{p.resolve()}'" for p in parts))
        (
            ffmpeg.input(str(concat_list), format="concat", safe=0)
            .output(str(output_path), c="copy")
            .overwrite_output()
            .run(quiet=True)
        )
        concat_list.unlink(missing_ok=True)


def get_tts_engine() -> TTSEngine:
    """Factory - swap the returned class here to change the TTS backend globally."""
    return EdgeTTSEngine()
