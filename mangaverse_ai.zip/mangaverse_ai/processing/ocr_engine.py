"""
OCR engine - fully free/offline, no API keys required.

- manga-ocr: purpose-trained transformer model for Japanese manga text
  (handles speech bubbles, vertical text, stylized fonts far better than
  generic OCR).
- pytesseract: used for English text and as a general fallback.

Both engines are lazy-loaded on first use since manga-ocr loads a model
into memory (a few hundred MB) - we don't want that cost paid at import
time if the bot is idle.
"""
from __future__ import annotations

import re
from pathlib import Path

from PIL import Image

from core.logger import get_logger

logger = get_logger(__name__)

_manga_ocr_model = None


def _get_manga_ocr():
    global _manga_ocr_model
    if _manga_ocr_model is None:
        from manga_ocr import MangaOcr  # heavy import, deferred
        logger.info("Loading manga-ocr model (first run may take a while)...")
        _manga_ocr_model = MangaOcr()
    return _manga_ocr_model


_JAPANESE_RE = re.compile(r"[\u3040-\u30ff\u4e00-\u9fff]")


def _looks_japanese(text: str) -> bool:
    return bool(_JAPANESE_RE.search(text))


def ocr_page(image_path: Path) -> str:
    """Runs OCR on a single page image, auto-detecting JP vs EN text regions."""
    import pytesseract

    image = Image.open(image_path).convert("RGB")

    # Quick pass with tesseract (fast) to guess script, then use the
    # specialized manga-ocr model for Japanese-heavy pages.
    quick_text = pytesseract.image_to_string(image, lang="jpn+eng")

    if _looks_japanese(quick_text):
        try:
            mocr = _get_manga_ocr()
            text = mocr(image)
        except Exception as exc:  # noqa: BLE001
            logger.warning("manga-ocr failed on %s (%s), falling back to tesseract", image_path, exc)
            text = quick_text
    else:
        text = quick_text

    return text.strip()


def ocr_pages(image_paths: list[Path]) -> str:
    """OCRs all pages in order and returns one combined text block."""
    chunks = []
    for i, path in enumerate(image_paths, start=1):
        text = ocr_page(path)
        if text:
            chunks.append(f"[Page {i}]\n{text}")
    return "\n\n".join(chunks)
