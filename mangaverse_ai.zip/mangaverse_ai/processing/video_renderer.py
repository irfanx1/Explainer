"""
Renders the final explainer video: manga pages displayed in sync with the
narration audio (Ken Burns-style slow zoom for a more dynamic feel),
using ffmpeg under the hood via moviepy.
"""
from __future__ import annotations

from pathlib import Path

from moviepy.editor import AudioFileClip, ImageClip, concatenate_videoclips

from core.logger import get_logger

logger = get_logger(__name__)

QUALITY_PRESETS = {
    "480p": (854, 480),
    "720p": (1280, 720),
    "1080p": (1920, 1080),
}


def render_video(
    page_paths: list[Path],
    audio_path: Path,
    output_path: Path,
    quality: str = "720p",
) -> Path:
    width, height = QUALITY_PRESETS.get(quality, QUALITY_PRESETS["720p"])

    audio_clip = AudioFileClip(str(audio_path))
    total_duration = audio_clip.duration
    per_page_duration = max(total_duration / max(len(page_paths), 1), 1.5)

    clips = []
    for page_path in page_paths:
        clip = (
            ImageClip(str(page_path))
            .set_duration(per_page_duration)
            .resize(height=height)
        )
        # Center on a fixed-size canvas so portrait/landscape pages both look clean
        clip = clip.on_color(size=(width, height), color=(10, 10, 15), pos="center")
        # subtle Ken Burns zoom for a more dynamic, "explainer video" feel
        clip = clip.resize(lambda t: 1 + 0.02 * t)
        clips.append(clip)

    video = concatenate_videoclips(clips, method="compose").set_audio(audio_clip)
    video = video.set_duration(total_duration)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    video.write_videofile(
        str(output_path),
        fps=24,
        codec="libx264",
        audio_codec="aac",
        threads=2,
        logger=None,
    )

    audio_clip.close()
    video.close()
    logger.info("Rendered video to %s", output_path)
    return output_path
