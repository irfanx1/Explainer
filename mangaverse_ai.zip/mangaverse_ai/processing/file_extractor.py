"""Extracts manga pages (as image files) from PDF, CBZ, ZIP, RAR/CBR, or raw images."""
from __future__ import annotations

import shutil
import zipfile
from pathlib import Path

import fitz  # PyMuPDF
import rarfile

from core.logger import get_logger

logger = get_logger(__name__)

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}


def extract_pages(source_path: Path, workdir: Path) -> list[Path]:
    """
    Extracts all pages from the given manga file into workdir/pages/
    and returns a sorted list of image paths.
    """
    pages_dir = workdir / "pages"
    pages_dir.mkdir(parents=True, exist_ok=True)
    suffix = source_path.suffix.lower()

    if suffix == ".pdf":
        _extract_pdf(source_path, pages_dir)
    elif suffix in {".zip", ".cbz"}:
        _extract_zip(source_path, pages_dir)
    elif suffix in {".rar", ".cbr"}:
        _extract_rar(source_path, pages_dir)
    elif suffix in IMAGE_EXTS:
        shutil.copy(source_path, pages_dir / source_path.name)
    else:
        raise ValueError(f"Unsupported file type: {suffix}")

    pages = sorted(
        [p for p in pages_dir.iterdir() if p.suffix.lower() in IMAGE_EXTS],
        key=lambda p: p.name,
    )
    if not pages:
        raise ValueError("No readable pages/images were found in the uploaded file.")
    logger.info("Extracted %d pages from %s", len(pages), source_path.name)
    return pages


def _extract_pdf(path: Path, out_dir: Path) -> None:
    doc = fitz.open(path)
    for i, page in enumerate(doc, start=1):
        pix = page.get_pixmap(dpi=200)
        pix.save(out_dir / f"page_{i:04d}.png")
    doc.close()


def _extract_zip(path: Path, out_dir: Path) -> None:
    with zipfile.ZipFile(path) as zf:
        for i, name in enumerate(sorted(zf.namelist()), start=1):
            if Path(name).suffix.lower() in IMAGE_EXTS:
                data = zf.read(name)
                target = out_dir / f"page_{i:04d}{Path(name).suffix.lower()}"
                target.write_bytes(data)


def _extract_rar(path: Path, out_dir: Path) -> None:
    with rarfile.RarFile(path) as rf:
        for i, name in enumerate(sorted(rf.namelist()), start=1):
            if Path(name).suffix.lower() in IMAGE_EXTS:
                data = rf.read(name)
                target = out_dir / f"page_{i:04d}{Path(name).suffix.lower()}"
                target.write_bytes(data)
