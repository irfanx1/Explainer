"""Turns OCR'd + translated manga text into a natural narration script."""
from __future__ import annotations

from ai_providers.provider_manager import provider_manager
from core.logger import get_logger

logger = get_logger(__name__)


async def generate_narration_script(manga_text: str, language: str = "en") -> str:
    """
    Uses the AI provider chain (Gemini -> Grok fallback) to analyze the
    manga's story and produce an exciting, natural narration script,
    ready to be fed into the TTS engine.
    """
    if not manga_text.strip():
        raise ValueError("No text could be extracted from this manga to narrate.")

    script = await provider_manager.analyze_and_narrate(manga_text, language=language)

    # Basic cleanup: strip stray markdown the model sometimes adds
    script = script.replace("**", "").replace("##", "").strip()
    return script
