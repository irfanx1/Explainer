"""
Tries providers in order (Gemini -> Grok -> ...future providers) and
transparently falls back if one fails or is rate-limited. To add a new
provider: implement AIProvider in a new file and append it to _build_chain().
"""
from __future__ import annotations

from ai_providers.base import AIProvider, ProviderError
from ai_providers.gemini_provider import GeminiProvider
from ai_providers.grok_provider import GrokProvider
from config import settings
from core.logger import get_logger

logger = get_logger(__name__)


class ProviderManager:
    def __init__(self):
        self._providers: list[AIProvider] = self._build_chain()
        if not self._providers:
            raise RuntimeError(
                "No AI providers are configured. Set at least GEMINI_API_KEY in .env"
            )

    @staticmethod
    def _build_chain() -> list[AIProvider]:
        chain: list[AIProvider] = []
        try:
            chain.append(GeminiProvider())
            logger.info("Gemini provider ready (primary)")
        except ProviderError as e:
            logger.warning("Gemini provider unavailable: %s", e)

        if settings.grok_api_key:
            try:
                chain.append(GrokProvider())
                logger.info("Grok provider ready (backup)")
            except ProviderError as e:
                logger.warning("Grok provider unavailable: %s", e)

        return chain

    async def generate_text(self, prompt: str, *, max_tokens: int = 2048) -> str:
        last_error: Exception | None = None
        for provider in self._providers:
            try:
                return await provider.generate_text(prompt, max_tokens=max_tokens)
            except ProviderError as e:
                logger.warning("Provider %s failed, trying next in chain...", provider.name)
                last_error = e
                continue
        raise ProviderError(f"All AI providers failed. Last error: {last_error}")

    async def analyze_and_narrate(self, ocr_text: str, language: str = "en") -> str:
        last_error: Exception | None = None
        for provider in self._providers:
            try:
                return await provider.analyze_and_narrate(ocr_text, language=language)
            except ProviderError as e:
                logger.warning("Provider %s failed for narration, trying next...", provider.name)
                last_error = e
                continue
        raise ProviderError(f"All AI providers failed to generate narration: {last_error}")


provider_manager = ProviderManager()
