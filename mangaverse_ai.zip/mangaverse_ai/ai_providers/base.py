"""Abstract interface every AI provider (Gemini, Grok, future ones) must implement."""
from __future__ import annotations

from abc import ABC, abstractmethod


class ProviderError(Exception):
    """Raised when a provider fails or is rate-limited - triggers fallback."""


class AIProvider(ABC):
    name: str = "base"

    @abstractmethod
    async def generate_text(self, prompt: str, *, max_tokens: int = 2048) -> str:
        """Send a prompt, return raw text response. Raise ProviderError on failure."""
        raise NotImplementedError

    async def analyze_and_narrate(self, ocr_text: str, language: str = "en") -> str:
        """
        Default implementation shared by all providers: build a prompt that turns
        raw OCR'd manga text into an exciting, natural narration script.
        Providers can override this if they need custom prompt formatting.
        """
        prompt = _build_narration_prompt(ocr_text, language)
        return await self.generate_text(prompt, max_tokens=3000)


def _build_narration_prompt(ocr_text: str, language: str) -> str:
    lang_line = "Write the narration in English." if language == "en" else \
                "Write the narration in the requested target language, keeping character names untranslated."
    return f"""You are a charismatic anime/manga YouTube explainer, similar to popular
manga-recap channels. Read the extracted manga page text below (it may contain
OCR noise, out-of-order panels, or mixed Japanese/English) and produce a
natural, exciting, easy-to-follow spoken narration script that:

- Explains the story, characters, emotions, fights, and hidden details/foreshadowing
- Sounds like a real human host talking, NOT robotic or repetitive
- Uses varied sentence structure and natural transitions ("Now here's where it gets interesting...")
- Preserves original character names and important terms exactly as written
- Is organized in the same order the story happens
- Does not include stage directions, timestamps, or markdown - plain spoken narration only

{lang_line}

RAW MANGA TEXT (OCR extracted, may be imperfect):
---
{ocr_text}
---

Narration script:"""
