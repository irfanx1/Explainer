"""Google Gemini provider (primary, free tier via https://aistudio.google.com/apikey)."""
from __future__ import annotations

import asyncio

import google.generativeai as genai

from ai_providers.base import AIProvider, ProviderError
from config import settings
from core.logger import get_logger

logger = get_logger(__name__)


class GeminiProvider(AIProvider):
    name = "gemini"

    def __init__(self):
        if not settings.gemini_api_key:
            raise ProviderError("GEMINI_API_KEY is not configured")
        genai.configure(api_key=settings.gemini_api_key)
        self._model = genai.GenerativeModel(settings.gemini_model)

    async def generate_text(self, prompt: str, *, max_tokens: int = 2048) -> str:
        try:
            # google-generativeai's client is sync; run it in a thread so we
            # don't block the asyncio event loop.
            response = await asyncio.to_thread(
                self._model.generate_content,
                prompt,
                generation_config={"max_output_tokens": max_tokens, "temperature": 0.85},
            )
            text = getattr(response, "text", None)
            if not text:
                raise ProviderError("Gemini returned an empty response")
            return text.strip()
        except Exception as exc:  # noqa: BLE001 - normalize all provider errors
            logger.warning("Gemini request failed: %s", exc)
            raise ProviderError(f"Gemini error: {exc}") from exc
