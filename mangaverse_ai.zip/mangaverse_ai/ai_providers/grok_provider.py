"""
Grok (xAI) backup provider. Uses the OpenAI-compatible /chat/completions
REST endpoint so no extra SDK is required. Only activated if GROK_API_KEY
is set in .env - entirely optional.
"""
from __future__ import annotations

import httpx

from ai_providers.base import AIProvider, ProviderError
from config import settings
from core.logger import get_logger

logger = get_logger(__name__)


class GrokProvider(AIProvider):
    name = "grok"

    def __init__(self):
        if not settings.grok_api_key:
            raise ProviderError("GROK_API_KEY is not configured")
        self._base_url = settings.grok_base_url.rstrip("/")
        self._headers = {
            "Authorization": f"Bearer {settings.grok_api_key}",
            "Content-Type": "application/json",
        }

    async def generate_text(self, prompt: str, *, max_tokens: int = 2048) -> str:
        payload = {
            "model": settings.grok_model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.85,
        }
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                resp = await client.post(
                    f"{self._base_url}/chat/completions", json=payload, headers=self._headers
                )
                resp.raise_for_status()
                data = resp.json()
                content = data["choices"][0]["message"]["content"]
                if not content:
                    raise ProviderError("Grok returned an empty response")
                return content.strip()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Grok request failed: %s", exc)
            raise ProviderError(f"Grok error: {exc}") from exc
