# MangaVerse AI — Telegram Manga Explainer Bot

Send a manga (PDF, CBZ, ZIP, CBR, or images), reply `/manga`, and get back a
fully narrated explainer video: pages are read, OCR'd, understood by AI,
turned into an exciting narration script, voiced with a free human-like TTS,
and rendered into video — all with free/free-tier tools.

## ✨ Features
- Multi-format input: PDF, CBZ, ZIP, CBR/RAR, raw images
- Japanese + English OCR (manga-ocr + tesseract), auto-detected
- AI story understanding & narration via **Gemini** (free), with automatic
  fallback to **Grok** if configured — new providers can be added by
  implementing `ai_providers/base.py`
- Free, human-like TTS via `edge-tts` (no API key)
- Video rendering with ffmpeg/moviepy, 3 quality presets
- Clean Telegram UI: premium `/start` menu, live progress updates, inline buttons
- Full admin panel: broadcast, stats, queue status, ban/unban, maintenance
  mode, log viewer, server (CPU/RAM/Disk) status, worker restart
- User features: queue system, cancel, history, language & quality settings, retry

## 🗂️ Project Structure
```
config.py                 # env-based settings
main.py                   # entrypoint
core/                     # logging, database (SQLAlchemy async), queue manager
ai_providers/             # Gemini + Grok providers behind a common interface
processing/               # extraction, OCR, translation, narration, TTS, video
bot/                      # Pyrogram client, keyboards, handlers (user + admin)
utils/                    # validators, system stats, helpers
```

## 🚀 Setup

### 1. Requirements
- Python 3.11+
- ffmpeg installed on the system (`apt install ffmpeg`)
- tesseract-ocr with Japanese pack (`apt install tesseract-ocr tesseract-ocr-jpn`) — used as a fallback OCR
- (Only needed for `.rar`/`.cbr` support) `unrar` installed

### 2. Get free API keys
- **Telegram**: `API_ID`/`API_HASH` from https://my.telegram.org, `BOT_TOKEN` from [@BotFather](https://t.me/BotFather)
- **Gemini** (primary AI, free tier): https://aistudio.google.com/apikey
- **Grok** (optional backup): https://console.x.ai — leave blank to skip

### 3. Install & configure
```bash
git clone <this project>
cd mangaverse_ai
cp .env.example .env      # fill in your keys
pip install -r requirements.txt
python main.py
```

### 4. Docker (optional)
```bash
docker compose up -d --build
```

### 5. Railway / Render
- Push this repo, set the same environment variables from `.env.example`
  in the platform's dashboard, and set the start command to `python main.py`.
- Make sure the build step installs `ffmpeg` and `tesseract-ocr` (add an
  `apt.txt` / Dockerfile-based deploy so these system packages are present).

## 🔧 Extending
- **Add an AI provider**: implement `AIProvider` in `ai_providers/`, register
  it in `provider_manager.py`'s `_build_chain()`.
- **Swap TTS engine**: implement `TTSEngine` in `processing/tts_engine.py`
  and update `get_tts_engine()`.
- **Move to PostgreSQL**: change `DATABASE_URL` in `.env` to a
  `postgresql+asyncpg://...` URL — no code changes needed.
- **Scale the queue**: `core/queue_manager.py` is in-process/async by design
  (free to run anywhere); swap it for Celery/RQ + Redis if you outgrow a
  single worker.

## ⚠️ Notes
- This is a full working scaffold covering the entire pipeline end-to-end.
  Before going to production, test each stage (OCR quality, TTS voice,
  render performance) against real manga files on your target VPS, since
  performance depends heavily on available CPU (video rendering and OCR are
  the heaviest steps).
- Respect copyright: only use this bot on manga you have the rights to process.
