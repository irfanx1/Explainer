"""
Central configuration for MangaVerse AI.
All secrets/settings are loaded from environment variables (.env file).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()


def _bool(val: str | None, default: bool = False) -> bool:
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


def _int_list(val: str | None) -> list[int]:
    if not val:
        return []
    return [int(x.strip()) for x in val.split(",") if x.strip()]


@dataclass(frozen=True)
class Settings:
    # Telegram
    api_id: int = int(os.getenv("API_ID", "0"))
    api_hash: str = os.getenv("API_HASH", "")
    bot_token: str = os.getenv("BOT_TOKEN", "")
    admin_ids: list[int] = field(default_factory=lambda: _int_list(os.getenv("ADMIN_IDS")))

    # AI providers
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
    grok_api_key: str = os.getenv("GROK_API_KEY", "")
    grok_model: str = os.getenv("GROK_MODEL", "grok-2-latest")
    grok_base_url: str = os.getenv("GROK_BASE_URL", "https://api.x.ai/v1")

    # Database
    database_url: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///data/mangaverse.db")

    # TTS
    tts_voice_en: str = os.getenv("TTS_VOICE_EN", "en-US-GuyNeural")
    tts_voice_ja: str = os.getenv("TTS_VOICE_JA", "ja-JP-KeitaNeural")

    # Processing
    max_file_size_mb: int = int(os.getenv("MAX_FILE_SIZE_MB", "200"))
    max_concurrent_jobs: int = int(os.getenv("MAX_CONCURRENT_JOBS", "2"))
    job_timeout_seconds: int = int(os.getenv("JOB_TIMEOUT_SECONDS", "1800"))

    # Misc
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    maintenance_mode: bool = _bool(os.getenv("MAINTENANCE_MODE"), False)
    temp_dir: Path = Path(os.getenv("TEMP_DIR", "temp"))
    data_dir: Path = Path(os.getenv("DATA_DIR", "data"))

    def validate(self) -> None:
        missing = []
        if not self.api_id:
            missing.append("API_ID")
        if not self.api_hash:
            missing.append("API_HASH")
        if not self.bot_token:
            missing.append("BOT_TOKEN")
        if not self.gemini_api_key:
            missing.append("GEMINI_API_KEY")
        if missing:
            raise RuntimeError(
                f"Missing required environment variables: {', '.join(missing)}. "
                "Copy .env.example to .env and fill them in."
            )


settings = Settings()
settings.temp_dir.mkdir(parents=True, exist_ok=True)
settings.data_dir.mkdir(parents=True, exist_ok=True)
