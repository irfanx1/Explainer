"""CPU/RAM/Disk stats for the admin /server command."""
from __future__ import annotations

import psutil


def get_server_status() -> str:
    cpu = psutil.cpu_percent(interval=0.5)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")

    return (
        "🖥️ **Server Status**\n\n"
        f"⚙️ CPU Usage: `{cpu:.1f}%`\n"
        f"🧠 RAM: `{mem.used / (1024**3):.1f} GB / {mem.total / (1024**3):.1f} GB` ({mem.percent:.1f}%)\n"
        f"💾 Disk: `{disk.used / (1024**3):.1f} GB / {disk.total / (1024**3):.1f} GB` ({disk.percent:.1f}%)\n"
    )
