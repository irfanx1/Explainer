"""Validation helpers for uploaded manga files."""
from __future__ import annotations

from config import settings

ALLOWED_EXTENSIONS = {".pdf", ".zip", ".cbz", ".rar", ".cbr", ".jpg", ".jpeg", ".png", ".webp"}


def is_supported_extension(filename: str) -> bool:
    return any(filename.lower().endswith(ext) for ext in ALLOWED_EXTENSIONS)


def is_within_size_limit(size_bytes: int) -> bool:
    return size_bytes <= settings.max_file_size_mb * 1024 * 1024


def validate_upload(filename: str, size_bytes: int) -> tuple[bool, str]:
    if not is_supported_extension(filename):
        return False, (
            f"Unsupported file type. Please send a PDF, CBZ, ZIP, CBR/RAR, or image "
            f"({', '.join(sorted(ALLOWED_EXTENSIONS))})."
        )
    if not is_within_size_limit(size_bytes):
        return False, f"File is too large. Max size is {settings.max_file_size_mb}MB."
    return True, ""
