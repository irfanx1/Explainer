"""Small shared helper functions."""
from __future__ import annotations

from pyrogram.errors import MessageNotModified
from pyrogram.types import Message

from core.models import JobStatus

STATUS_EMOJI = {
    JobStatus.QUEUED: "⏳",
    JobStatus.READING: "📖",
    JobStatus.UNDERSTANDING: "🧠",
    JobStatus.VOICING: "🎙️",
    JobStatus.RENDERING: "🎬",
    JobStatus.UPLOADING: "✅",
    JobStatus.DONE: "🎉",
    JobStatus.FAILED: "❌",
    JobStatus.CANCELLED: "🚫",
}


async def safe_edit(message: Message, text: str, **kwargs) -> None:
    """Edits a message, silently ignoring 'message not modified' errors."""
    try:
        await message.edit_text(text, **kwargs)
    except MessageNotModified:
        pass


def human_size(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:.1f}{unit}"
        size /= 1024
    return f"{size:.1f}TB"


def build_progress_text(status: JobStatus, detail: str, queue_position: int = 0) -> str:
    emoji = STATUS_EMOJI.get(status, "⏳")
    lines = [f"{emoji} {detail}"]
    if status == JobStatus.QUEUED and queue_position:
        lines.append(f"\n📍 Position in queue: {queue_position}")
    return "\n".join(lines)
