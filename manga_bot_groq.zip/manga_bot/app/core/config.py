"""
Central configuration — reads from environment / .env file.
"""
from __future__ import annotations

import os
from functools import lru_cache
from typing import List, Literal, Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── App ───────────────────────────────────────────────────
    app_env: Literal["development", "production"] = "production"
    secret_key: str = "change_me"
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    log_level: str = "INFO"
    temp_dir: str = "/tmp/mangabot"
    upload_max_mb: int = 100
    max_concurrent_jobs: int = 3

    # ── Telegram ──────────────────────────────────────────────
    telegram_bot_token: str
    telegram_admin_ids: List[int] = Field(default_factory=list)

    @field_validator("telegram_admin_ids", mode="before")
    @classmethod
    def parse_admin_ids(cls, v):
        if isinstance(v, str):
            return [int(x.strip()) for x in v.split(",") if x.strip()]
        return v

    # ── Database ──────────────────────────────────────────────
    database_url: str = "postgresql+asyncpg://mangabot:password@postgres:5432/mangabot"
    postgres_host: str = "postgres"
    postgres_port: int = 5432
    postgres_db: str = "mangabot"
    postgres_user: str = "mangabot"
    postgres_password: str = "password"

    # ── Redis ─────────────────────────────────────────────────
    redis_url: str = "redis://redis:6379/0"
    celery_broker_url: str = "redis://redis:6379/1"
    celery_result_backend: str = "redis://redis:6379/2"

    # ── AI Provider ───────────────────────────────────────────
    # Primary: groq (free, fast) | gemini (free) | openai (paid)
    ai_provider: Literal["groq", "gemini", "openai"] = "groq"

    # Groq (free — https://console.groq.com)
    groq_api_key: Optional[str] = None
    groq_model: str = "llama-3.3-70b-versatile"

    # Gemini (free — https://aistudio.google.com)
    gemini_api_key: Optional[str] = None
    gemini_model: str = "gemini-1.5-flash"

    # OpenAI (paid — kept for backwards compat)
    openai_api_key: Optional[str] = None
    openai_model: str = "gpt-4o"

    # ── OCR ───────────────────────────────────────────────────
    ocr_engine: Literal["tesseract", "google_vision", "easyocr"] = "tesseract"
    google_vision_api_key: Optional[str] = None

    # ── TTS ───────────────────────────────────────────────────
    tts_engine: Literal["gtts", "elevenlabs", "coqui"] = "gtts"
    gtts_lang: str = "hi"
    elevenlabs_api_key: Optional[str] = None

    # ── Video ─────────────────────────────────────────────────
    default_quality: Literal["480p", "720p", "1080p"] = "720p"
    gpu_enabled: bool = False
    ffmpeg_threads: int = 4
    max_video_duration_seconds: int = 600

    # ── Storage ───────────────────────────────────────────────
    storage_backend: Literal["local", "s3", "gcs"] = "local"
    s3_bucket: Optional[str] = None
    s3_region: str = "ap-south-1"
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    gcs_bucket: Optional[str] = None
    gcs_credentials_json: Optional[str] = None

    # ── Admin ─────────────────────────────────────────────────
    admin_username: str = "admin"
    admin_password: str = "changeme"

    # ── YouTube ───────────────────────────────────────────────
    youtube_upload_enabled: bool = False
    youtube_client_secrets_json: Optional[str] = None

    # ── Derived helpers ───────────────────────────────────────
    @property
    def upload_max_bytes(self) -> int:
        return self.upload_max_mb * 1024 * 1024

    @property
    def is_dev(self) -> bool:
        return self.app_env == "development"

    @property
    def quality_presets(self) -> dict:
        return {
            "480p":  {"width": 854,  "height": 480,  "bitrate": "800k",  "crf": 28},
            "720p":  {"width": 1280, "height": 720,  "bitrate": "2500k", "crf": 23},
            "1080p": {"width": 1920, "height": 1080, "bitrate": "5000k", "crf": 18},
        }


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
